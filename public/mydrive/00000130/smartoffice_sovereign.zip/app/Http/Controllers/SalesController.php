<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class SalesController extends Controller
{

    //Customer
    public function customerinfo()
    {
        $data = DB::table('pro_customers')->Where('valid', '1')->orderBy('customer_id', 'desc')->get(); //query builder
        return view('sales.customer_info', compact('data'));
    }

    public function customer_info_store(Request $request)
    {
        $rules = [
            'txt_customer_name' => 'required',
            'txt_customer_add' => 'required',
            // 'txt_customer_phone' => 'required',
        ];
        $customMessages = [
            'txt_customer_name.required' => 'Customer Name is required.',
            'txt_customer_add.required' => 'Customer Address is required.',
            // 'txt_customer_phone.required' => 'Customer Phone is required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_customers')->where('customer_name', $request->txt_customer_name)->where('customer_add', $request->txt_customer_add)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['customer_name'] = $request->txt_customer_name;
            $data['customer_add'] = $request->txt_customer_add;
            $data['customer_phone'] = $request->txt_customer_phone;
            $data['customer_email'] = $request->txt_customer_email;
            $data['contact_person'] = $request->txt_contact_person;
            $data['valid'] = $m_valid;
            // dd($data);
            DB::table('pro_customers')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function customer_info_edit($id)
    {

        $m_customer = DB::table('pro_customers')->where('customer_id', $id)->first();

        return view('sales.customer_info', compact('m_customer'));
    }

    public function customer_info_update(Request $request, $update)
    {

        $rules = [
            'txt_customer_name' => 'required',
            'txt_customer_add' => 'required',
            // 'txt_customer_phone' => 'required',
        ];
        $customMessages = [
            'txt_customer_name.required' => 'Customer Name is required.',
            'txt_customer_add.required' => 'Customer Address is required.',
            // 'txt_customer_phone.required' => 'Customer Phone Number is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_customers = DB::table('pro_customers')->where('customer_id', $request->txt_customer_id)->where('customer_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_customers === null) {

            DB::table('pro_customers')->where('customer_id', $update)->update([
                'customer_name' => $request->txt_customer_name,
                'customer_add' => $request->txt_customer_add,
                'customer_phone' => $request->txt_customer_phone,
                'customer_email' => $request->txt_customer_email,
                'contact_person' => $request->txt_contact_person,
            ]);

            return redirect(route('customer_info'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }


    //quotation
    public function sales_quotation()
    {
       $quotation = DB::table('pro_sales_quotation')->where('status',1)->get();
        return view('sales.sales_quotation',compact('quotation'));
    }

    public function sales_quotation_store(Request $request)
    {

        $rules = [
            'txt_date' => 'required',
            'txt_customer' => 'required',
            // 'txt_customer_phone' => 'required',
        ];
        $customMessages = [
            'txt_date.required' => 'Quatation date is required.',
            'txt_customer.required' => 'Customer Name is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $last_inv_no = DB::table('pro_sales_quotation')->orderByDesc("quotation_no")->first();
        if (isset($last_inv_no->quotation_no)) {
            $quotation_no = "SOVQO" . date("my") . str_pad((substr($last_inv_no->quotation_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $quotation_no = "SOVQO" . date("my") . "00001";
        }

        $data = array();
        $data['quotation_no'] = $quotation_no;
        $data['quotation_date'] = $request->txt_date;
        $data['customer_name'] = $request->txt_customer;
        $data['customer_add'] = $request->txt_address;
        $data['customer_phone'] = $request->txt_mobile_number;
        $data['customer_email'] = $request->txt_email;
        $data['reff_name'] = $request->txt_reference_name;
        $data['reff_phone'] = $request->txt_reference_number;
        $data['floore'] = $request->txt_floore;
        $data['capacity'] = $request->txt_capacity;
        $data['price'] = $request->txt_price;
        $data['user_id'] =Auth::user()->emp_id;
        $data['remark'] = $request->txt_remark;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        DB::table('pro_sales_quotation')->insert($data);

        return back()->with('success', 'Add Successfully.');
    }
}
