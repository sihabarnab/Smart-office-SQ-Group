<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    //Product Group
    public function inventoryproductgroup()
    {
        $data = DB::table('pro_product_group')->Where('valid', '1')->orderBy('pg_id', 'desc')->get(); //query builder
        return view('inventory.product_group', compact('data'));

        // return view('inventory.product_group');
    }

    public function inventorypgstore(Request $request)
    {
        $rules = [
            'txt_pg_name' => 'required'
        ];
        $customMessages = [
            'txt_pg_name.required' => 'Product Group Name is required.'
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_product_group')->where('pg_name', $request->txt_pg_name)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['pg_name'] = $request->txt_pg_name;
            $data['valid'] = $m_valid;
            // dd($data);
            DB::table('pro_product_group')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success');
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function inventorypgedit($id)
    {

        $m_pg = DB::table('pro_product_group')->where('pg_id', $id)->first();
        // return response()->json($data);
        $data = DB::table('pro_product_group')->Where('valid', '1')->orderBy('pg_id', 'desc')->get();
        return view('inventory.product_group', compact('data', 'm_pg'));
    }

    public function inventorypgupdate(Request $request, $update)
    {

        $rules = [
            'txt_pg_name' => 'required',
        ];
        $customMessages = [
            'txt_pg_name.required' => 'Product Group Name is required.'
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_product_group = DB::table('pro_product_group')->where('pg_id', $request->txt_pg_id)->where('pg_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_product_group === null) {

            DB::table('pro_product_group')->where('pg_id', $update)->update([
                'pg_name' => $request->txt_pg_name,
            ]);

            return redirect(route('product_group'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Product Sub Group
    public function inventoryproductsubgroup()
    {
        $data = DB::table('pro_product_sub_group')->Where('valid', '1')->orderBy('pg_sub_id', 'desc')->get(); //query builder
        return view('inventory.product_sub_group', compact('data'));

        // return view('inventory.product_group');
    }

    public function inventorypgsubstore(Request $request)
    {
        $rules = [
            'sele_pg_id' => 'required|integer|between:1,10000',
            'txt_pg_sub_name' => 'required',
        ];
        $customMessages = [
            'sele_pg_id.required' => 'Select Product Group.',
            'sele_pg_id.integer' => 'Select Product Group.',
            'sele_pg_id.between' => 'Select Product Group.',

            'txt_pg_sub_name.required' => 'Product Sub Group Name is required.'
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_product_sub_group')->where('pg_sub_name', $request->txt_pg_sub_name)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['pg_id'] = $request->sele_pg_id;
            $data['pg_sub_name'] = $request->txt_pg_sub_name;
            $data['valid'] = $m_valid;
            // dd($data);
            DB::table('pro_product_sub_group')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            // $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success' );
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function inventorypgsubedit($id)
    {

        $m_pg_sub = DB::table('pro_product_sub_group')->where('pg_sub_id', $id)->first();
        // return response()->json($data);
        $data = DB::table('pro_product_sub_group')->Where('valid', '1')->orderBy('pg_sub_id', 'desc')->get();
        return view('inventory.product_sub_group', compact('data', 'm_pg_sub'));
    }

    public function inventorypgsubupdate(Request $request, $update)
    {

        $rules = [
            'sele_pg_id' => 'required|integer|between:1,10000',
            'txt_pg_sub_name' => 'required',
        ];
        $customMessages = [
            'sele_pg_id.required' => 'Select Product Group.',
            'sele_pg_id.integer' => 'Select Product Group.',
            'sele_pg_id.between' => 'Select Product Group.',

            'txt_pg_sub_name.required' => 'Product Sub Group Name is required.'
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_product_sub_group = DB::table('pro_product_sub_group')->where('pg_sub_id', $request->txt_pg_sub_id)->where('pg_sub_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_product_sub_group === null) {

            DB::table('pro_product_sub_group')->where('pg_sub_id', $update)->update([
                'pg_id' => $request->sele_pg_id,
                'pg_sub_name' => $request->txt_pg_sub_name,
            ]);

            return redirect(route('product_sub_group'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Product
    public function inventoryproduct()
    {
        $data = DB::table('pro_product')->Where('valid', '1')->orderBy('pg_id', 'desc')->get(); //query builder
        return view('inventory.product', compact('data'));

        // return view('inventory.product_group');
    }

    public function inventoryproductstore(Request $request)
    {
        $rules = [
            'sele_pg_id' => 'required|integer|between:1,10000',
            'sele_pg_sub_id' => 'required|integer|between:1,10000',
            'txt_product_name' => 'required',
            'sele_unit_id' => 'required|integer|between:1,10000',
        ];
        $customMessages = [
            'sele_pg_id.required' => 'Select Product Group.',
            'sele_pg_id.integer' => 'Select Product Group.',
            'sele_pg_id.between' => 'Select Product Group.',

            'sele_pg_sub_id.required' => 'Select Product Sub Group.',
            'sele_pg_sub_id.integer' => 'Select Product Sub Group.',
            'sele_pg_sub_id.between' => 'Select Product Sub Group.',

            'txt_product_name.required' => 'Product Name is required.',

            'sele_unit_id.required' => 'Select Unit.',
            'sele_unit_id.integer' => 'Select Unit.',
            'sele_unit_id.between' => 'Select Unit.',

        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_product')->where('pg_id', $request->sele_pg_id)->where('product_name', $request->txt_product_name)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $mentrydate = time();
            $m_entry_date = date("Y-m-d", $mentrydate);
            $m_entry_time = date("H:i:s", $mentrydate);

            $data = array();
            $data['pg_id'] = $request->sele_pg_id;
            $data['pg_sub_id'] = $request->sele_pg_sub_id;
            $data['product_name'] = $request->txt_product_name;
            $data['unit_id'] = $request->sele_unit_id;
            $data['product_des'] = $request->txt_product_des;
            $data['size_id'] = $request->sele_size_id;
            $data['origin_id'] = $request->sele_origin_id;
            $data['user_id'] = $request->txt_user_id;
            $data['valid'] = $m_valid;
            $data['entry_date'] = $m_entry_date;
            $data['entry_time'] = $m_entry_time;
            // dd($data);
            DB::table('pro_product')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            // $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success' );
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function inventoryproductedit($id)
    {

        $m_product = DB::table('pro_product')->where('product_id', $id)->first();
        // return response()->json($data);
        $data = DB::table('pro_product')->Where('valid', '1')->orderBy('product_id', 'desc')->get();
        return view('inventory.product', compact('data', 'm_product'));
    }

    public function inventoryproductupdate(Request $request, $update)
    {

        $rules = [
            'sele_pg_id' => 'required|integer|between:1,10000',
            'sele_pg_sub_id' => 'required|integer|between:1,10000',
            'txt_product_name' => 'required',
            'sele_unit_id' => 'required|integer|between:1,10000',
        ];
        $customMessages = [
            'sele_pg_id.required' => 'Select Product Group.',
            'sele_pg_id.integer' => 'Select Product Group.',
            'sele_pg_id.between' => 'Select Product Group.',

            'sele_pg_sub_id.required' => 'Select Product Sub Group.',
            'sele_pg_sub_id.integer' => 'Select Product Sub Group.',
            'sele_pg_sub_id.between' => 'Select Product Sub Group.',

            'txt_product_name.required' => 'Product Name is required.',

            'sele_unit_id.required' => 'Select Unit.',
            'sele_unit_id.integer' => 'Select Unit.',
            'sele_unit_id.between' => 'Select Unit.',
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_product = DB::table('pro_product')->where('product_id', $request->txt_product_id)->where('product_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_product === null) {

            DB::table('pro_product')->where('product_id', $update)->update([
                'pg_id' => $request->sele_pg_id,
                'pg_sub_id' => $request->sele_pg_sub_id,
                'product_name' => $request->txt_product_name,
                'unit_id' => $request->sele_unit_id,
                'product_des' => $request->txt_product_des,
                'size_id' => $request->sele_size_id,
                'origin_id' => $request->sele_origin_id,
            ]);

            return redirect(route('product'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Product Unit
    public function productunit()
    {
        $data = DB::table('pro_units')->Where('valid', '1')->orderBy('unit_id', 'desc')->get(); //query builder
        return view('inventory.product_unit', compact('data'));

        // return view('inventory.product_group');
    }

    public function unitstore(Request $request)
    {
        $rules = [
            'txt_unit_name' => 'required'
        ];
        $customMessages = [
            'txt_unit_name.required' => 'Unit Name is required.'
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_units')->where('unit_name', $request->txt_unit_name)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['unit_name'] = strtoupper($request->txt_unit_name);
            $data['valid'] = $m_valid;
            $data['created_at'] = date('Y-m-d H:i:s');

            // dd($data);
            DB::table('pro_units')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success');
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function prounitedit($id)
    {

        $m_unit = DB::table('pro_units')->where('unit_id', $id)->first();
        // return response()->json($data);
        $data = DB::table('pro_units')->Where('valid', '1')->orderBy('unit_id', 'desc')->get();
        return view('inventory.product_unit', compact('data', 'm_unit'));
    }

    public function prounitupdate(Request $request, $update)
    {

        $rules = [
            'txt_unit_name' => 'required',
        ];
        $customMessages = [
            'txt_unit_name.required' => 'Unit Name is required.'
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_units = DB::table('pro_units')->where('unit_id', $request->txt_unit_id)->where('unit_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_units === null) {

            DB::table('pro_units')->where('unit_id', $update)->update([
                'unit_name' => strtoupper($request->txt_unit_name),
            ]);

            return redirect(route('product_unit'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Product Size
    public function productsize()
    {
        $data = DB::table('pro_sizes')->Where('valid', '1')->orderBy('size_id', 'desc')->get(); //query builder
        return view('inventory.product_size', compact('data'));
    }

    public function sizestore(Request $request)
    {
        $rules = [
            'txt_size_name' => 'required'
        ];
        $customMessages = [
            'txt_size_name.required' => 'Size Name is required.'
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_sizes')->where('size_name', $request->txt_size_name)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['size_name'] = $request->txt_size_name;
            $data['valid'] = $m_valid;
            $data['created_at'] = date('Y-m-d H:i:s');

            // dd($data);
            DB::table('pro_sizes')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success');
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function prosizeedit($id)
    {

        $m_size = DB::table('pro_sizes')->where('size_id', $id)->first();
        // return response()->json($data);
        $data = DB::table('pro_sizes')->Where('valid', '1')->orderBy('size_id', 'desc')->get();
        return view('inventory.product_size', compact('data', 'm_size'));
    }

    public function prosizeupdate(Request $request, $update)
    {

        $rules = [
            'txt_size_name' => 'required',
        ];
        $customMessages = [
            'txt_size_name.required' => 'Size Name is required.'
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_sizes = DB::table('pro_sizes')->where('size_id', $request->txt_size_id)->where('size_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_sizes === null) {

            DB::table('pro_sizes')->where('size_id', $update)->update([
                'size_name' => $request->txt_size_name,
            ]);

            return redirect(route('product_size'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Product Origin
    public function productorigin()
    {
        $data = DB::table('pro_origins')->Where('valid', '1')->orderBy('origin_id', 'desc')->get(); //query builder
        return view('inventory.product_origin', compact('data'));
    }

    public function originstore(Request $request)
    {
        $rules = [
            'txt_origin_name' => 'required'
        ];
        $customMessages = [
            'txt_origin_name.required' => 'Origin Name is required.'
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_origins')->where('origin_name', $request->txt_origin_name)->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['origin_name'] = $request->txt_origin_name;
            $data['valid'] = $m_valid;
            $data['created_at'] = date('Y-m-d H:i:s');

            // dd($data);
            DB::table('pro_origins')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success');
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function prooriginedit($id)
    {

        $m_origin = DB::table('pro_origins')->where('origin_id', $id)->first();
        // return response()->json($data);
        $data = DB::table('pro_origins')->Where('valid', '1')->orderBy('origin_id', 'desc')->get();
        return view('inventory.product_origin', compact('data', 'm_origin'));
    }

    public function prooriginupdate(Request $request, $update)
    {

        $rules = [
            'txt_origin_name' => 'required',
        ];
        $customMessages = [
            'txt_origin_name.required' => 'Origin Name is required.'
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_origins = DB::table('pro_origins')->where('origin_id', $request->txt_origin_id)->where('origin_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_origins === null) {

            DB::table('pro_origins')->where('origin_id', $update)->update([
                'origin_name' => $request->txt_origin_name,
            ]);

            return redirect(route('product_origin'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Supplier
    public function supplierinfo()
    {
        $data = DB::table('pro_suppliers')->Where('valid', '1')->orderBy('supplier_id', 'desc')->get(); //query builder
        return view('inventory.supplier_info', compact('data'));

        // return view('inventory.product_group');
    }

    public function supplier_info_store(Request $request)
    {
        $rules = [
            'txt_supplier_name' => 'required',
            'txt_supplier_add' => 'required',
            'txt_supplier_phone' => 'required',
        ];
        $customMessages = [
            'txt_supplier_name.required' => 'Supplier Name is required.',
            'txt_supplier_add.required' => 'Supplier Address is required.',
            'txt_supplier_phone.required' => 'Supplier Phone Number is required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('pro_suppliers')
            ->where('supplier_name', $request->txt_supplier_name)
            ->first();
        //dd($abcd);

        if ($abcd === null) {
            $m_valid = '1';
            $data = array();
            $data['supplier_name'] = $request->txt_supplier_name;
            $data['supplier_add'] = $request->txt_supplier_add;
            $data['supplier_phone'] = $request->txt_supplier_phone;
            $data['supplier_email'] = $request->txt_supplier_email;
            $data['contact_person'] = $request->txt_contact_person;
            $data['valid'] = $m_valid;
            $data['entry_date'] = date('Y-m-d');
            $data['entry_time'] = date('H:i:s');

            // dd($data);
            DB::table('pro_suppliers')->insert($data);
            return redirect()->back()->with('success', 'Data Inserted Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    public function supplier_info_edit($id)
    {

        $m_supplier = DB::table('pro_suppliers')->where('supplier_id', $id)->first();

        // $data=DB::table('pro_suppliers')->Where('valid','1')->orderBy('supplier_id', 'desc')->get();
        return view('inventory.supplier_info', compact('m_supplier'));
    }

    public function supplier_info_update(Request $request, $update)
    {

        $rules = [
            'txt_supplier_name' => 'required',
            'txt_supplier_add' => 'required',
            'txt_supplier_phone' => 'required',
        ];
        $customMessages = [
            'txt_supplier_name.required' => 'Supplier Name is required.',
            'txt_supplier_add.required' => 'Supplier Address is required.',
            'txt_supplier_phone.required' => 'Supplier Phone Number is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_pro_suppliers = DB::table('pro_suppliers')->where('supplier_id', $request->txt_supplier_id)->where('supplier_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_pro_suppliers === null) {

            DB::table('pro_suppliers')->where('supplier_id', $update)->update([
                'supplier_name' => $request->txt_supplier_name,
                'supplier_add' => $request->txt_supplier_add,
                'supplier_phone' => $request->txt_supplier_phone,
                'supplier_email' => $request->txt_supplier_email,
                'contact_person' => $request->txt_contact_person,
            ]);

            return redirect(route('supplier_info'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //Receving Report

    //
    public function rr_info()
    {
        $m_master = DB::table('pro_purchase_master')->where('status', 2)->where('rr_status', null)->get();
        return view('inventory.rr_info', compact('m_master'));
    }

    public function rr_master_create($id)
    {
        $pu_master = DB::table('pro_purchase_master')->where('purchase_no', $id)->first();
        return view('inventory.rr_master_create', compact('pu_master'));
    }

    public function rr_master_store(Request $request, $id)
    {

        $rules = [
            'txt_chalan_no' => 'required',
            'txt_challan_date' => 'required',
        ];
        $customMessages = [
            'txt_chalan_no.required' => 'Challan No is required.',
            'txt_challan_date.required' => 'Challan Date is required.',

        ];
        $this->validate($request, $rules, $customMessages);

        $pu_master = DB::table('pro_purchase_master')->where('purchase_no', $id)->first();

        $last_inv_no = DB::table('pro_receving_report_master')->orderByDesc("rr_no")->first();
        if (isset($last_inv_no->rr_no)) {
            $rr_no = "SOVRR" . date("my") . str_pad((substr($last_inv_no->rr_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $rr_no = "SOVRR" . date("my") . "00001";
        }

        DB::table('pro_receving_report_master')->insertGetId([
            'rr_no' => $rr_no,
            'purchase_no' =>  $pu_master->purchase_no,
            'purchase_date' =>  $pu_master->entry_date,
            'wo_invoice_no' =>  $pu_master->wo_invoice_no,
            'wo_invoice_date' =>  $pu_master->wo_invoice_date,
            'quotation_invoice_no' =>  $pu_master->quotation_invoice_no,
            'quotation_date' =>  $pu_master->quotation_date,
            'indent_no' =>  $pu_master->indent_no,
            'indent_date' =>  $pu_master->indent_date,
            'reference' => $pu_master->reference,
            'supplier_id' => $pu_master->supplier_id,
            'chalan_no' => $request->txt_chalan_no,
            'chalan_date' => $request->txt_challan_date,
            'lc_no' => $request->txt_lc_no,
            'lc_date' => $request->txt_lc_date,
            'user_id' => Auth::user()->emp_id,
            'status' => 1,
            'valid' => 1,
            'entry_date' => date("Y-m-d"),
            'entry_time' => date("h:i:sa"),
        ]);

        return redirect()->route('rr_details_create', $rr_no);
    }

    public function rr_details_create($id)
    {
        $rr_master = DB::table('pro_receving_report_master')->where('rr_no', $id)->first();
        $m_supplyer = DB::table('pro_suppliers')->where('supplier_id', $rr_master->supplier_id)->first();
        $product_id = DB::table('pro_receving_report_details')->where('rr_no', $id)->pluck('product_id');
        $pg_id = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->whereNotIn('product_id', $product_id)->where('rr_status', null)->pluck('pg_id');
        $product_group = DB::table('pro_product_group')->whereIn('pg_id', $pg_id)->get();
        $rr_details = DB::table('pro_receving_report_details')->where('rr_no', $id)->get();
        return view('inventory.rr_details_create', compact('rr_master', 'm_supplyer', 'product_group', 'rr_details'));
    }

    public function rr_details_store(Request $request, $id)
    {
        $rules = [
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_product_qty' => 'required',
            //  'txt_product_rate' => 'required',
        ];
        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_product_qty.required' => 'QTY is required!',
            //  'txt_product_rate.required' => 'Rate is required!',

        ];
        $this->validate($request, $rules, $customMessages);

        $rr_master = DB::table('pro_receving_report_master')->where('rr_no', $id)->first();
        $unit = DB::table('pro_product')->where('product_id', $request->cbo_product)->first();
        $purchase = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->where('product_id', $request->cbo_product)->first();

        $purchase->rr_qty == null ? ($qty = $request->txt_product_qty) : ($qty = $request->txt_product_qty + $purchase->rr_qty);

        if ($qty > $purchase->approved_qty) {
            return back()->with('warning', "Receving qty getter then purchase Qty($qty>$purchase->approved_qty)");
        } else {

            $data = array();
            $data['rr_master_id'] = $rr_master->rr_master_id;
            $data['rr_no'] = $rr_master->rr_no;
            $data['purchase_no'] = $rr_master->purchase_no;
            $data['purchase_date'] = $rr_master->purchase_date;
            $data['indent_no'] = $rr_master->indent_no;
            $data['indent_date'] = $rr_master->indent_date;
            $data['quotation_invoice_no'] = $rr_master->quotation_invoice_no;
            $data['quotation_date'] = $rr_master->quotation_date;
            $data['wo_invoice_no'] = $rr_master->wo_invoice_no;
            $data['wo_invoice_date'] = $rr_master->wo_invoice_date;
            $data['pg_id'] = $request->cbo_product_group;
            $data['pg_sub_id'] = $request->cbo_product_sub_group;
            $data['product_id'] = $request->cbo_product;
            $data['unit_id'] = $unit->unit_id;
            $data['old_qty'] = $purchase->approved_qty;
            $data['qty'] = $request->txt_product_qty;
            $data['rate'] = $request->txt_product_rate;
            $data['total'] = ($request->txt_product_qty * $request->txt_product_rate);
            $data['remark'] = $request->txt_remark;
            $data['user_id'] = Auth::user()->emp_id;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:sa");
            DB::table('pro_receving_report_details')->insert($data);
            DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->where('product_id', $request->cbo_product)->update(['rr_qty' => $request->txt_product_qty]);

            if ($qty == $purchase->approved_qty) {
                DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->where('product_id', $request->cbo_product)->update(['rr_status' => 1]);
            }

            $data1 = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->count();
            $data2 = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->where('rr_status', 1)->count();
            if ($data1 == $data2) {
                $data = DB::table('pro_purchase_master')->where('purchase_no', $rr_master->purchase_no)->update(['rr_status' => 1]);
            }

            return back()->with('success', "Add Successfully!");
        }
    }

    public function rr_details_final($id)
    {
        DB::table('pro_receving_report_master')->where('rr_no', $id)->update(['status' => 2]);
        DB::table('pro_receving_report_details')->where('rr_no', $id)->update(['status' => 2]);
        return redirect()->route('rr_info');
    }

    public function rpt_rr_list()
    {
        $rr_master = DB::table('pro_receving_report_master')->where('status', 2)->get();
        return view('inventory.rpt_rr_list', compact('rr_master'));
    }

    public function rpt_rr_details($id)
    {
        $rr_master = DB::table('pro_receving_report_master')->where('rr_no', $id)->first();
        $rr_details = DB::table('pro_receving_report_details')->where('rr_no', $id)->get();
        return view('inventory.rpt_rr_details', compact('rr_master', 'rr_details'));
    }

    //RR Ajax
    public function GetRRSubGroup($id, $id2)
    {
        $rr_master = DB::table('pro_receving_report_master')->where('rr_no', $id2)->first();
        $product_id = DB::table('pro_receving_report_details')->where('rr_no', $id2)->pluck('product_id');
        $pg_sub_id = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->whereNotIn('product_id', $product_id)->where('rr_status', null)->pluck('pg_sub_id');
        $data = DB::table('pro_product_sub_group')->where('pg_id', $id)->whereIn('pg_sub_id', $pg_sub_id)->get();
        return response()->json($data);
    }

    public function GetRRProduct($id, $id2)
    {
        $rr_master = DB::table('pro_receving_report_master')->where('rr_no', $id2)->first();
        $rr_product_id = DB::table('pro_receving_report_details')->where('rr_no', $id2)->pluck('product_id');
        $product_id = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->whereNotIn('product_id', $rr_product_id)->where('rr_status', null)->pluck('product_id');
        $data = DB::table('pro_product')->where('pg_sub_id', $id)->whereIn('product_id', $product_id)->get();
        return response()->json($data);
    }
    public function GetRRPurchaseProductQty($id, $id2)
    {
        $rr_master = DB::table('pro_receving_report_master')->where('rr_no', $id2)->first();
        $rr_details = DB::table('pro_receving_report_details')->where('rr_no', $id2)->where('product_id', $id)->first();
        $purchase = DB::table('pro_purchase_details')->where('purchase_no', $rr_master->purchase_no)->where('product_id', $id)->first();

        $data = array();
        if ($purchase->rr_qty == null) {
            $data['pursace_qty'] = $purchase->approved_qty;
            $data['rr_qty'] = $purchase->approved_qty;
            $data['receive_qty'] = '0';
        } else {
            $data['pursace_qty'] = $purchase->approved_qty;
            $data['rr_qty']  = $purchase->approved_qty - $purchase->rr_qty;
            $data['receive_qty'] = $purchase->rr_qty;
        }

        return response()->json($data);
    }

    //End RR 

    //Material Issue
    public function material_issue_info()
    {
        $m_requisition_master = DB::table('pro_requisition_master')->where('status', 4)->where('issue_status', null)->get();
        return view('inventory.material_issue_info', compact('m_requisition_master'));
    }

    public function material_issue_create($id)
    {
        $req_master = DB::table('pro_requisition_master')->where('requisition_master_id', $id)->first();
        $ms_task_assign = DB::table('pro_task_assign')->where('task_id', $req_master->task_id)->first();
        return view('inventory.material_issue_master', compact('req_master', 'ms_task_assign'));
    }

    public function material_issue_master_store(Request $request, $id)
    {
        $req_master = DB::table('pro_requisition_master')->where('requisition_master_id', $id)->first();
        $ms_task_assign = DB::table('pro_task_assign')->where('task_id', $req_master->task_id)->first();

        $last_inv_no = DB::table('pro_material_issue_master')->orderByDesc("mi_master_no")->first();
        if (isset($last_inv_no->mi_master_no)) {
            $mi_master_no = "SOVMI" . date("my") . str_pad((substr($last_inv_no->mi_master_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $mi_master_no = "SOVMI" . date("my") . "00001";
        }

        $data = array();
        $data['mi_master_no'] = $mi_master_no;
        $data['requisition_master_id'] = $req_master->requisition_master_id;
        $data['req_no'] = $req_master->req_no;
        $data['req_date'] = $req_master->entry_date;
        $data['complain_id'] = $req_master->complain_id;
        $data['task_id'] = $req_master->task_id;
        $data['customer_id'] = $ms_task_assign->customer_id;
        $data['team_leader_id'] = $req_master->team_leader_id;
        $data['department_id'] = $req_master->department_id;
        $data['remark'] = $request->txt_remark;
        $data['user_id'] = Auth::user()->emp_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        DB::table('pro_material_issue_master')->insert($data);
        return redirect()->route('material_issue_details', $mi_master_no);
    }

    public function material_issue_details($id)
    {
        $mi_master = DB::table('pro_material_issue_master')->where('mi_master_no', $id)->first();
        $mi_details = DB::table('pro_material_issue_details')->where('mi_master_no', $id)->get();
        $product_id = DB::table('pro_material_issue_details')->where('req_no', $id)->pluck('product_id');
        $pg_id = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->whereNotIn('product_id', $product_id)->where('issue_status', null)->pluck('pg_id');
        $product_group = DB::table('pro_product_group')->whereIn('pg_id', $pg_id)->get();
        return view('inventory.material_issue_details', compact('mi_master', 'mi_details', 'product_group'));
    }

    public function material_issue_details_store(Request $request, $id)
    {
        $rules = [
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_issue_qty' => 'required',
        ];
        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_issue_qty.required' => 'Issue Qty is required!',

        ];
        $this->validate($request, $rules, $customMessages);

        $mi_master = DB::table('pro_material_issue_master')->where('mi_master_no', $id)->first();
        $requction = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->where('product_id', $request->cbo_product)->first();
        $unit = DB::table('pro_product')->where('product_id', $request->cbo_product)->first();


        $requction->mi_qty == null ? ($qty = $request->txt_issue_qty) : ($qty = $request->txt_issue_qty + $requction->mi_qty);

        if ($request->txt_issue_qty > $request->txt_stock_qty) {
            return back()->with('warning', "Issue qty getter then Stock Qty($request->txt_issue_qty> $request->txt_stock_qty)");
        } elseif ($qty > $requction->approved_qty) {
            return back()->with('warning', "Material Issue qty getter then requation Qty($qty>$requction->approved_qty)");
        } else {

            $data = array();
            $data['mi_master_no'] = $mi_master->mi_master_no;
            $data['requisition_master_id'] = $mi_master->requisition_master_id;
            $data['req_no'] = $mi_master->req_no;
            $data['req_date'] = $mi_master->entry_date;
            $data['complain_id'] = $mi_master->complain_id;
            $data['task_id'] = $mi_master->task_id;
            $data['customer_id'] = $mi_master->customer_id;
            $data['team_leader_id'] = $mi_master->team_leader_id;
            $data['department_id'] = $mi_master->department_id;


            $data['pg_id'] = $request->cbo_product_group;
            $data['pg_sub_id'] = $request->cbo_product_sub_group;
            $data['product_id'] = $request->cbo_product;
            $data['unit_id'] = $unit->unit_id;
            $data['req_qty'] = $requction->approved_qty;
            $data['issue_qty'] = $request->txt_issue_qty;
            $data['remark'] = $request->txt_remark;
            $data['user_id'] = Auth::user()->emp_id;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:sa");
            DB::table('pro_material_issue_details')->insert($data);
            DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->where('product_id', $request->cbo_product)->update(['mi_qty' => $request->txt_issue_qty]);

            if ($qty == $requction->approved_qty) {
                DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->where('product_id', $request->cbo_product)->update(['issue_status' => 1]);
            }

            $data1 = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->count();
            $data2 = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->where('issue_status', 1)->count();
            if ($data1 == $data2) {
                $data = DB::table('pro_requisition_master')->where('req_no', $mi_master->req_no)->update(['issue_status' => 1]);
            }

            return back()->with('success', "Add Successfully!");
        }
    }

    public function material_issue_final($id)
    {
        DB::table('pro_material_issue_master')->where('mi_master_no', $id)->update(['status' => 2]);
        DB::table('pro_material_issue_details')->where('mi_master_no', $id)->update(['status' => 2]);
        return redirect()->route('material_issue_info');
    }

    public function rpt_issue_list()
    {
        $issue_master =  DB::table('pro_material_issue_master')->where('status', 2)->get();
        return view('inventory.rpt_issue_list', compact('issue_master'));
    }

    public function rpt_issue_details($id)
    {
        $issue_master = DB::table('pro_material_issue_master')->where('mi_master_no', $id)->first();
        $issue_details = DB::table('pro_material_issue_details')->where('mi_master_no', $id)->get();
        return view('inventory.rpt_issue_details', compact('issue_master', 'issue_details'));
    }



    //Ajax
    public function GetMISubGroup($id, $id2)
    {
        $mi_master = DB::table('pro_material_issue_master')->where('mi_master_no', $id2)->first();
        $product_id = DB::table('pro_material_issue_details')->where('mi_master_no', $id2)->pluck('product_id');
        $pg_sub_id = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->whereNotIn('product_id', $product_id)->where('issue_status', null)->pluck('pg_sub_id');
        $data = DB::table('pro_product_sub_group')->where('pg_id', $id)->whereIn('pg_sub_id', $pg_sub_id)->get();
        return response()->json($data);
    }

    public function GetMIProduct($id, $id2)
    {
        $mi_master = DB::table('pro_material_issue_master')->where('mi_master_no', $id2)->first();
        $product_id = DB::table('pro_material_issue_details')->where('mi_master_no', $id2)->pluck('product_id');
        $product_id = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->whereNotIn('product_id', $product_id)->where('issue_status', null)->pluck('product_id');
        $data = DB::table('pro_product')->where('pg_sub_id', $id)->whereIn('product_id', $product_id)->get();
        return response()->json($data);
    }

    public function GetMIProductDetails($id, $id2)
    {
        $mi_master = DB::table('pro_material_issue_master')->where('mi_master_no', $id2)->first();
        $requction = DB::table('pro_requisition_details')->where('req_no', $mi_master->req_no)->where('product_id', $id)->first();
        $product = DB::table('pro_product')->where('product_id', $id)->first();
        $unit = DB::table('pro_units')->where('unit_id', $product->unit_id)->first();

        $data = array();
        $data['unit_name'] = $unit->unit_name;
        if ($requction->mi_qty == null) {
            $data['requsition_qty'] = $requction->approved_qty;
            $data['mi_qty'] = '0';
            $data['issue_qty'] = $requction->approved_qty;
        } else {
            $data['requsition_qty'] = $requction->approved_qty;
            $data['mi_qty'] = $requction->mi_qty;
            $data['issue_qty']  = $requction->approved_qty - $requction->mi_qty;
        }

        return response()->json($data);
    }

    public function GetMIProductStock($id, $id2)
    {
        $issue_qty = DB::table('pro_material_issue_details')->where('mi_master_no', $id2)->where('product_id', $id)->sum('issue_qty');
        $rr_qty = DB::table('pro_receving_report_details')->where('product_id', $id)->sum('qty');
        $data =  $rr_qty  -  $issue_qty;
        return json_encode($data);
    }

    //End Material Issue

    // Report Product stock
    public function RptProductStock()
    {
        return view('inventory.rpt_product_stock');
    }

  //Report Product stock list
  public function RptProductStockList(Request $request)
  {
      $rules = [
          'cbo_product_group' => 'required|integer|between:1,10000',
      ];
      $customMessages = [
          'cbo_product_group.required' => 'Select Product Group.',
          'cbo_product_group.integer' => 'Select Product Group.',
          'cbo_product_group.between' => 'Select Product Group.',
      ];
      $this->validate($request, $rules, $customMessages);

      $m_from_date = $request->txt_from_date;
      $m_to_date = $request->txt_to_date;
      // dd("$m_from_date -- $m_to_date");
      if ($m_from_date === NULL && $m_to_date === NULL) {

          $mentrydate = time();
          $m_current_date = date("Y-m-d", $mentrydate);
          $m_current_year = date("Y", $mentrydate);
          $m_current_month = date("m", $mentrydate);

          $txt_start_date = "$m_current_year-$m_current_month-01";
          // $last_day_this_month = date('t', strtotime($txt_to_date));
          $txt_end_date = "$m_current_date";

          $closing_date = date('Y-m-d', strtotime('-1 month', strtotime($txt_start_date)));
          $closing_year = substr($closing_date, 0, 4);
          $closing_month = substr($closing_date, 5, 2);
          $txt_day = 0;
          $m_date = 0;
      } else {
          if ($m_from_date > $m_to_date) {
              return redirect()->back()->withInput()->with('warning', 'Date Mismatch!!');
          } else {
              $m_day = substr($m_from_date, 8, 2);
              $m_month = substr($m_from_date, 5, 2);
              $m_year = substr($m_from_date, 0, 4);
              // $txt_day=$m_day;

              if ($m_day > 01) {

                  $txt_start_date = "$m_from_date";
                  $txt_end_date = "$m_to_date";

                  $m_date = "$m_year-$m_month-01";

                  $closing_date = date('Y-m-d', strtotime('-1 month', strtotime($m_date)));
                  $closing_year = substr($closing_date, 0, 4);
                  $closing_month = substr($closing_date, 5, 2);
                  $txt_day = $m_day;


                  // dd("aaaaaaaaa $m_day");
              } else {

                  $txt_start_date = "$m_from_date";
                  $txt_end_date = "$m_to_date";

                  $closing_date = date('Y-m-d', strtotime('-1 month', strtotime($txt_start_date)));
                  $closing_year = substr($closing_date, 0, 4);
                  $closing_month = substr($closing_date, 5, 2);
                  $txt_day = 0;
                  $m_date = 0;
              }
          } //if($m_from_date>$m_to_date)

      } //if($m_from_date === NULL && $m_to_date === NULL)

      $txt_pg_id = $request->cbo_product_group;
      $txt_sub_pg_id = $request->cbo_product_sub_group;
      $txt_product_id = $request->cbo_product;


      // dd("$m_day -- $txt_start_date -- $txt_end_date -- $txt_pg_id -- $txt_sub_pg_id --$txt_product_id");

      if ($txt_sub_pg_id == 0 && $txt_product_id == 0) {
          // dd("$txt_pg_id");

          $ci_product_list  = DB::table('pro_product')
              ->leftJoin('pro_product_group', 'pro_product.pg_id', 'pro_product_group.pg_id')
              ->leftJoin('pro_product_sub_group', 'pro_product.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
              ->leftJoin('pro_units', 'pro_product.unit_id', 'pro_units.unit_id')
              ->select('pro_product.*', 'pro_product_group.pg_name', 'pro_product_sub_group.pg_sub_name', 'pro_units.unit_name')
              ->where("pro_product.pg_id", $txt_pg_id)
              ->where("pro_product.valid", 1)
              ->get();

          return view('inventory.rpt_product_stock', compact('txt_start_date', 'txt_end_date', 'closing_year', 'closing_month', 'ci_product_list', 'txt_day', 'm_date'));
      } else if ($txt_product_id == 0) {
          // dd("$txt_pg_id -- $txt_sub_pg_id");

          $ci_product_list  = DB::table('pro_product')
              ->leftJoin('pro_product_group', 'pro_product.pg_id', 'pro_product_group.pg_id')
              ->leftJoin('pro_product_sub_group', 'pro_product.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
              ->leftJoin('pro_units', 'pro_product.unit_id', 'pro_units.unit_id')
              ->select('pro_product.*', 'pro_product_group.pg_name', 'pro_product_sub_group.pg_sub_name', 'pro_units.unit_name')
              ->where("pro_product.pg_id", $txt_pg_id)
              ->where("pro_product.pg_sub_id", $txt_sub_pg_id)
              ->where("pro_product.valid", 1)
              ->get();

          return view('inventory.rpt_product_stock', compact('txt_start_date', 'txt_end_date', 'closing_year', 'closing_month', 'ci_product_list', 'txt_day', 'm_date'));
      }   else { 
          $ci_product_list  = DB::table('pro_product')
              ->leftJoin('pro_product_group', 'pro_product.pg_id', 'pro_product_group.pg_id')
              ->leftJoin('pro_product_sub_group', 'pro_product.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
              ->leftJoin('pro_units', 'pro_product.unit_id', 'pro_units.unit_id')
              ->select('pro_product.*', 'pro_product_group.pg_name', 'pro_product_sub_group.pg_sub_name', 'pro_units.unit_name')
              ->where("pro_product.pg_id", $txt_pg_id)
              ->where("pro_product.pg_sub_id", $txt_sub_pg_id)
              ->where("pro_product.product_id", $txt_product_id)
              // ->where("pro_product.product_id", $txt_product_id)
              ->where("pro_product.valid", 1)
              ->get();

          return view('inventory.rpt_product_stock', compact('txt_start_date', 'txt_end_date', 'closing_year', 'closing_month', 'ci_product_list', 'txt_day', 'm_date'));
      }

  }

    //End Product Stock
}
