<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin/home');
    }

//Company
    public function admincuser()
    {
        $data=DB::table('users')->Where('valid','1')->orderBy('id', 'asc')->get(); //query builder
        return view('admin.create_user',compact('data'));

    }

    public function admincuserstore(Request $request)
    {
        $rules = [
            'sele_employee_id' => 'required|integer|between:1,99999999',
            'txt_password' => 'required|min:8|max:20',
                ];

        $customMessages = [
            'sele_employee_id.required' => 'Select Employee.',
            'sele_employee_id.integer' => 'Select Employee.',
            'sele_employee_id.between' => 'Select Employee.',

            'txt_password.required' => 'Password is required.',
            'txt_password.min' => 'Password must be at least 8 characters.',
            'txt_password.max' => 'Password not more 20 characters.',
        ];        
        $this->validate($request, $rules, $customMessages);

        $abcd = DB::table('users')->where('emp_id', $request->sele_employee_id)->first();
        //dd($abcd);
        
        if ($abcd === null)
        {

            $ci_employee_info=DB::table('pro_employee_info')->Where('employee_id',$request->sele_employee_id)->first();
            $txt_employee_name=$ci_employee_info->employee_name;

            $m_valid='1';
            $m_user_status='1';

            $data=array();
            $data['emp_id']=$request->sele_employee_id;
            $data['password']=Hash::make($request->txt_password);
            $data['user_status']=$m_user_status;
            $data['admin_id']=$request->txt_user_id;
            $data['full_name']=$txt_employee_name;
            $data['valid']=$m_valid;
            $data['created_at']=date('Y-m-d H:i:s');
            // dd($data);
            DB::table('users')->insert($data);
            return redirect()->back()->with('success','Data Inserted Successfully!');
        } else {
            $abcd1 = array('message' => 'Data duplicate', 'alert-type' => 'success' );
            //dd($abcd)
            return redirect()->back()->withInput()->with('warning' , 'Data already exists!!');  
        }
    }
   
    public function admincuseredit($id)
    {
        
        $m_user=DB::table('users')->where('emp_id',$id)->first();
        // return response()->json($data);
        $data=DB::table('users')->Where('valid','1')->orderBy('emp_id', 'desc')->get();
        return view('admin.create_user',compact('data','m_user'));
    }

    public function admincuserupdate(Request $request,$update)
    {

    $rules = [
            'sele_employee_id' => 'required|integer|between:1,99999999',
            'txt_password' => 'required|max:20|min:8',
        ];

        $customMessages = [

            'sele_employee_id.required' => 'Select Employee.',
            'sele_employee_id.integer' => 'Select Employee.',
            'sele_employee_id.between' => 'Chose Employee.',

            'txt_password.required' => 'Password is required.',
            'txt_password.min' => 'Password must be at least 8 characters.',
            'txt_password.max' => 'Password not more 20 characters.',

        ];        

        $this->validate($request, $rules, $customMessages);

        DB::table('users')->where('emp_id',$update)->update([
            'password'=>Hash::make($request->txt_password),
            'valid'=>$request->sele_valid,
            'updated_at'=>date('Y-m-d H:i:s'),

            ]);

        return redirect(route('create_user'))->with('success','Data Updated Successfully!');

    }

    // public function admincuser_permission($id)
    // {
        
    //     $m_user_permission=DB::table('users')->where('emp_id',$id)->first();
    //     // return response()->json($data);
    //     $data=DB::table('pro_sub_mnu_for_users')->Where('valid','1')->Where('emp_id',$m_user_permission->emp_id)->orderBy('sl_no', 'asc')->get();
    //     return view('admin.user_permission',compact('data','m_user_permission'));
    // }

    // public function moduleMainMenu(Request $request, $id)
    // {
    //     $data = DB::table('pro_main_mnu')->where('module_id',$id)->where('valid',1)->get();
    //     return response()->json(['data' => $data]);
    // }

//Sub Menu For User
      public function SubMenuforUser()
      {
          // return Auth::user(); 
          $companies = DB::table('pro_company')
          ->where('valid','1')
          ->get();
          $modules = DB::table('pro_module')->get();
          return view('admin.submenu_for_user', compact('companies', 'modules'));
      }
  
    public function sub_menu_user_list(Request $request)
    {
        return redirect()->route('sub_menu_user_info',[$request->cbo_employee_id,$request->cbo_main_menu_id,$request->cbo_module_id]);
    }

    public function sub_menu_user_info($id,$id2,$id3)
    {
      if ($id2=='0')
      {
        $sub_menu = DB::table('pro_sub_mnu')->get();
      } else {
        $sub_menu = DB::table('pro_sub_mnu')->where('main_mnu_id', $id2)->get(); 
      }
        $employee=$id;
        $module=$id3;
        $main_menu=$id2;
        return view('admin.menu_list', compact('sub_menu', 'employee','module','main_menu'));
    }
  
    //user sub menu store 
    public function sub_menu_user_store(Request $request, $id)
    {
        if ($request->txt_sub_menu_upd == 'on') {
            $check = DB::table('pro_sub_mnu_for_users')
                ->where('emp_id', $request->txt_employee_id)
                ->where('module_id', $request->txt_module_id)
                ->where('main_mnu_id', $request->txt_main_menu_id)
                ->where('sub_mnu_id', $id)
                ->first();

            if ($check) {
                $data = array();
                if ($request->txt_add == 'on') {
                    $data['select_opt'] = '1';
                } else {
                    $data['select_opt'] = '0';
                }

                if ($request->txt_edit == 'on') {
                    $data['edit_opt'] = '1';
                } else {
                    $data['edit_opt'] = '0';
                }

                if ($request->txt_view == 'on') {
                    $data['delete_opt'] = '1';
                } else {
                    $data['delete_opt'] = '0';
                }
                if ($request->txt_valid == 'on') {
                    $data['valid'] = '1';
                } else {
                    $data['valid'] = '0';
                }
                $data = DB::table('pro_sub_mnu_for_users')
                    ->where('emp_id', $request->txt_employee_id)
                    ->where('module_id', $request->txt_module_id)
                    ->where('main_mnu_id', $request->txt_main_menu_id)
                    ->where('sub_mnu_id', $id)
                    ->update($data);
            } else {
                $data = array();
                $data['emp_id'] = $request->txt_employee_id;
                $data['module_id'] = $request->txt_module_id;
                $data['main_mnu_id'] = $request->txt_main_menu_id;
                $data['sub_mnu_id'] =  $id;

                if ($request->txt_add == 'on') {
                    $data['select_opt'] = '1';
                } else {
                    $data['select_opt'] = '0';
                }

                if ($request->txt_edit == 'on') {
                    $data['edit_opt'] = '1';
                } else {
                    $data['edit_opt'] = '0';
                }

                if ($request->txt_view == 'on') {
                    $data['delete_opt'] = '1';
                } else {
                    $data['delete_opt'] = '0';
                }
                if ($request->txt_valid == 'on') {
                    $data['valid'] = '1';
                } else {
                    $data['valid'] = '0';
                }
                $data = DB::table('pro_sub_mnu_for_users')->insert($data);
            }
        } else {

            $data = array();
            $data['emp_id'] = $request->txt_employee_id;
            $data['module_id'] = $request->txt_module_id;
            $data['main_mnu_id'] = $request->txt_main_menu_id;
            $data['sub_mnu_id'] =  $id;

            if ($request->txt_add == 'on') {
                $data['select_opt'] = '1';
            } else {
                $data['select_opt'] = '0';
            }

            if ($request->txt_edit == 'on') {
                $data['edit_opt'] = '1';
            } else {
                $data['edit_opt'] = '0';
            }

            if ($request->txt_view == 'on') {
                $data['delete_opt'] = '1';
            } else {
                $data['delete_opt'] = '0';
            }
            if ($request->txt_valid == 'on') {
                $data['valid'] = '1';
            } else {
                $data['valid'] = '0';
            }
            $data = DB::table('pro_sub_mnu_for_users')->insert($data);
        }
        return back()->with('success', 'Add Successfull');
    }
  
    //New Module and Company
    public function UserModuleCompany()
    {
        $companies = DB::table('pro_company')
        ->where('valid','1')
        ->get();

        $employees = DB::table('pro_employee_info')->get();
        return view('admin.user_module_and_company', compact('employees','companies'));
    }

    public function user_mc_list(Request $request)
    {
        $rules = [
            'cbo_employee_id' => 'required',
            'cbo_blade' => 'required',
        ];

        $customMessages = [
            'cbo_employee_id.required' => 'Select Employee.',
            'cbo_blade.required' => 'Select Blade',
        ];
        $this->validate($request, $rules, $customMessages);

        if ($request->cbo_blade == 1) {
            return redirect()->route('user_module_edit', $request->cbo_employee_id);
        } elseif ($request->cbo_blade == 2) {
            return redirect()->route('user_company_edit', $request->cbo_employee_id);
        }
    }

 //Module
    public function user_module_edit($emp_id)
    {

        // $m_module = DB::table('pro_module_user')
        // ->where('pro_module_user.emp_id', $emp_id)
        // ->where('pro_module_user.valid', 1)
        // ->join('pro_module','pro_module_user.module_id','pro_module.module_id')
        // ->select('pro_module.*')
        // ->get();
        $m_module = DB::table('pro_module')->where('valid', 1)->get();
        return view('admin.user_module_list', compact('m_module', 'emp_id'));
    }
    public function user_module_update(Request $request, $id)
    {

        $check_module = DB::table('pro_module_user')
            ->where('emp_id', $id)
            ->where('module_id', $request->txt_module_id)
            ->first();

        if (isset($check_module)) {
            if ($request->txt_valid == "on") {
                DB::table('pro_module_user')
                    ->where('emp_id', $id)
                    ->where('module_id', $request->txt_module_id)
                    ->update(['valid' => 1]);
            } else {
                DB::table('pro_module_user')
                    ->where('emp_id', $id)
                    ->where('module_id', $request->txt_module_id)
                    ->update(['valid' => 0]);
            }
            return back()->with('success', 'Successfull Updated');
        } else {
            $data = array();
            $data['emp_id'] = $request->txt_employee_id;
            $data['module_id'] = $request->txt_module_id;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:sa");
            $data['valid'] = 1;
            DB::table('pro_module_user')->insert($data);
            return back()->with('success', 'Successfull Inserted');
        }
    }

 //comapny
    public function user_company_edit($emp_id)
    {
        $m_company = DB::table('pro_company')->where('valid', 1)->get();
        return view('admin.user_company_list', compact('m_company', 'emp_id'));
    }
    public function user_company_update(Request $request, $id)
    {
        $check_company = DB::table('pro_user_company')
            ->where('employee_id', $id)
            ->where('company_id', $request->txt_company_id)
            ->first();

        if (isset($check_company)) {
            if ($request->txt_valid == "on") {
                DB::table('pro_user_company')
                    ->where('employee_id', $id)
                    ->where('company_id', $request->txt_company_id)
                    ->update(['valid' => 1]);
            } else {
                DB::table('pro_user_company')
                    ->where('employee_id', $id)
                    ->where('company_id', $request->txt_company_id)
                    ->update(['valid' => 0]);
            }
            return back()->with('success', 'Successfull Updated');
        } else {
            $data = array();
            $data['employee_id'] = $request->txt_employee_id;
            $data['company_id'] = $request->txt_company_id;
            // $data['entry_date'] = date("Y-m-d");
            // $data['entry_time'] = date("h:i:sa");
            $data['valid'] = 1;
            DB::table('pro_user_company')->insert($data);
            return back()->with('success', 'Successfull Inserted');
        }
    }

      // Ajax Sub Menu For User Store

    public function GetEmployee1($id)
    {
        $data = DB::table('pro_employee_info')
        ->where('working_status', '1')
        // ->where('ss', '1')
        ->where('company_id', $id)
        ->orderBy('employee_id', 'asc')
        ->get();
        return json_encode($data);
    }

      public function GetCompany($id)
      {
          $data = DB::table('pro_employee_info')
          ->where('company_id', $id)
          ->where('valid', '1')
          ->orderBy('employee_id', 'asc')
          ->get();
          return response()->json($data);
      }
      public function GetMainMenu($id)
      {
          $data = DB::table('pro_main_mnu')
          ->where('module_id', $id)
          ->get();
          return response()->json($data);
      }





}