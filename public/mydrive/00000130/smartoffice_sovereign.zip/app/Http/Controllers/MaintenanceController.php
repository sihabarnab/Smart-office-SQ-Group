<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MaintenanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    //Team
    public function TeamInfo()
    {
        $teams = DB::table("pro_teams")
            ->join("pro_employee_info", "pro_teams.team_leader_id", "pro_employee_info.employee_id")
            ->select("pro_teams.*", "pro_employee_info.employee_name")
            ->get();
        $leaders = DB::table("pro_employee_info")->where('service_leader', NULL)->where('service_helper', NULL)->get();
        return view('maintenance.mt_team_info', compact('teams', 'leaders'));
    }
    public function TeamInfoStore(Request $request)
    {
        $rules = [
            'txt_team_name' => 'required',
            'cbo_leader_id' => 'required',
        ];
        $customMessages = [
            'txt_team_name.required' => 'Team name is required.',
            'cbo_leader_id.required' => 'Leader is required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $data = array();
        $data['team_name'] = $request->txt_team_name;
        $data['team_leader_id'] = $request->cbo_leader_id;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        $data['status'] = 1;
        $inserted = DB::table("pro_teams")->insert($data);

        if ($inserted) {
            DB::table("pro_employee_info")->where('employee_id', $request->cbo_leader_id)->update(["service_leader" => 1]);
        }
        return back()->with('success', "Data Inserted Successfully!");
    }
    //End Team

    //start project
    public function projectInfo()
    {
        $projects = DB::table("pro_projects")
            ->join("pro_customers", "pro_projects.customer_id", "pro_customers.customer_id")
            ->select("pro_projects.*", "pro_customers.customer_name")
            ->get();
        $customers = DB::table("pro_customers")
            ->where('valid', 1)
            ->get();

        return view('maintenance.mt_project_info', compact('projects', 'customers'));
    }
    public function ProjectInfoStore(Request $request)
    {

        $rules = [
            'txt_project_name' => 'required',
            'cbo_customer_id' => 'required|integer|between:1,10000',
            'txt_pro_address' => 'required',
            'txt_pro_lift_quantity' => 'required',
            // 'txt_pro_contact_date' => 'required',
            // 'txt_pro_installation_date' => 'required',
            // 'txt_pro_handover_date' => 'required',
            // 'txt_warranty' => 'required',
        ];
        $customMessages = [
            'txt_project_name.required' => 'Project name is required.',

            'cbo_customer_id.required' => 'Customer is required.',
            'cbo_customer_id.integer' => 'Customer is required.',
            'cbo_customer_id.between' => 'Customer is required.',

            'txt_pro_address.required' => 'Project address is required.',
            'txt_pro_lift_quantity.required' => 'Lift quantity is required.',
            // 'txt_pro_contact_date.required' => 'Date is required.',
            // 'txt_pro_installation_date.required' => 'Project installation Date is required.',
            // 'txt_pro_handover_date.required' => 'Project handover Date is required.',
            // 'txt_warranty.required' => 'Project warranty is required.',
        ];
        $this->validate($request, $rules, $customMessages);

        // $handover_date = $request->txt_pro_handover_date;
        // $warranty = $request->txt_warranty;
        // $time = strtotime("$handover_date");
        // $warranty_end_date = date("Y-m-d", strtotime("+$warranty month", $time));


        $check = DB::table("pro_projects")->where('project_name', $request->txt_project_name)->first();
        if (isset($check)) {
            return back()->with('warning', "Data Already Inserted !");
        } else {
            $data = array();
            $data['project_name'] = $request->txt_project_name;
            $data['customer_id'] = $request->cbo_customer_id;
            $data['project_address'] = $request->txt_pro_address;
            $data['pro_lift_quantity'] = $request->txt_pro_lift_quantity;
            $data['contact_date'] = $request->txt_pro_contact_date;
            $data['installation_date'] = $request->txt_pro_installation_date;
            $data['handover_date'] = $request->txt_pro_handover_date;
            $data['warranty'] = $request->txt_warranty;
            $data['service_warranty'] = $request->txt_service_warranty;
            $data['remark'] = $request->txt_remark;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:s");
            $data['valid'] = 1;
            DB::table("pro_projects")->insert($data);
            return back()->with('success', "Data Inserted Successfully!");
        }
    }

    public function project_info_edit($id)
    {
        $m_project = DB::table('pro_projects')->where('project_id', $id)->first();

        $m_customer = DB::table("pro_customers")
            ->where('valid', 1)
            ->get();

        return view('maintenance.mt_project_info', compact('m_project', 'm_customer'));
    }

    public function project_info_update(Request $request, $update)
    {

        $rules = [
            'txt_project_name' => 'required',
            'cbo_customer_id' => 'required|integer|between:1,10000',
            'txt_pro_address' => 'required',
            'txt_pro_lift_quantity' => 'required',
            // 'txt_pro_contact_date' => 'required',
            // 'txt_pro_installation_date' => 'required',
            // 'txt_pro_handover_date' => 'required',
            // 'txt_warranty' => 'required',
        ];
        $customMessages = [
            'txt_project_name.required' => 'Project name is required.',

            'cbo_customer_id.required' => 'Customer is required.',
            'cbo_customer_id.integer' => 'Customer is required.',
            'cbo_customer_id.between' => 'Customer is required.',

            'txt_pro_address.required' => 'Project address is required.',
            'txt_pro_lift_quantity.required' => 'Lift quantity is required.',
            // 'txt_pro_contact_date.required' => 'Lift Quantity is required.',
            // 'txt_pro_installation_date.required' => 'Project installation Date is required.',
            // 'txt_pro_handover_date.required' => 'Project handover Date is required.',
            // 'txt_warranty.required' => 'Project Warranty is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $ci_projects = DB::table('pro_projects')->where('project_id', $request->txt_project_id)->where('project_id', '<>', $update)->first();
        //dd($abcd);

        if ($ci_projects === null) {

            DB::table('pro_projects')->where('project_id', $update)->update([
                'project_name' => $request->txt_project_name,
                'customer_id' => $request->cbo_customer_id,
                'project_address' => $request->txt_pro_address,
                'pro_lift_quantity' => $request->txt_pro_lift_quantity,
                'contact_date' => $request->txt_pro_contact_date,
                'installation_date' => $request->txt_pro_installation_date,
                'handover_date' => $request->txt_pro_handover_date,
                'warranty' => $request->txt_warranty,
                'service_warranty' => $request->txt_service_warranty,
                'remark' => $request->txt_remark,
            ]);

            return redirect(route('mt_project_info'))->with('success', 'Data Updated Successfully!');
        } else {
            return redirect()->back()->withInput()->with('warning', 'Data already exists!!');
        }
    }

    //End project

    //Lift
    public function liftinfo()
    {
        $lifts = DB::table('pro_lifts')
            ->join("pro_projects", "pro_lifts.project_id", "pro_projects.project_id")
            ->select("pro_lifts.*", "pro_projects.project_name")
            ->get();
        $projects = DB::table('pro_projects')->get();
        return view('maintenance.mt_lift_info', compact('lifts', 'projects'));
    }
    public function lift_info_store(Request $request)
    {
        $rules = [
            'cbo_project_id' => 'required|integer|between:1,9999999',
            'txt_lift_name' => 'required',
        ];
        $customMessages = [
            'cbo_project_id.required' => 'Select Project.',
            'cbo_project_id.integer' => 'Select Project.',
            'cbo_project_id.between' => 'Select Project.',
            'txt_lift_name.required' => 'Lift name is required.',
        ];
        $this->validate($request, $rules, $customMessages);
        $data = array();
        $data['project_id'] = $request->cbo_project_id;
        $data['lift_name'] = $request->txt_lift_name;
        $data['remark'] = $request->txt_remark;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        DB::table("pro_lifts")->insert($data);
        return back()->with('success', "Inserted Successfull !");
    }
    public function lift_info_edit($id)
    {
        $m_lifts = DB::table('pro_lifts')->where('lift_id', $id)->first();
        $projects = DB::table('pro_projects')->get();
        return view('maintenance.mt_lift_info', compact('m_lifts', 'projects'));
    }
    public function lift_info_update(Request $request, $id)
    {
        $rules = [
            'cbo_project_id' => 'required|integer|between:1,999999999',
            'txt_lift_name' => 'required',
        ];
        $customMessages = [
            'cbo_project_id.required' => 'Select Project.',
            'cbo_project_id.integer' => 'Select Project.',
            'cbo_project_id.between' => 'Select Project.',
            'txt_lift_name.required' => 'Lift name is required.',
        ];
        $this->validate($request, $rules, $customMessages);
        $data = array();
        $data['project_id'] = $request->cbo_project_id;
        $data['lift_name'] = $request->txt_lift_name;
        $data['remark'] = $request->txt_remark;
        DB::table("pro_lifts")->where('lift_id', $id)->update($data);
        return redirect()->route('mt_lift_info')->with('success', "Updated Successfull !");
    }
    //End Lift


    //Contact Service 
    public function contractserviceinfo()
    {
        $contact_services = DB::table('pro_ct_services')
            ->join("pro_projects", "pro_ct_services.project_id", "pro_projects.project_id")
            ->join("pro_customers", "pro_projects.customer_id", "pro_customers.customer_id")
            ->select("pro_ct_services.*", "pro_projects.project_name", "pro_customers.customer_name")
            ->get();

        $projects = DB::table("pro_projects")
            ->where('valid', '1')
            ->get();

        $m_bill_type = DB::table("pro_bill_type")
            ->where('valid', '1')
            ->get();

        return view('maintenance.mt_contract_service_info', compact('contact_services', 'projects', 'm_bill_type'));
    }
    public function contract_service_info_store(Request $request)
    {
        $rules = [
            'cbo_project_id' => 'required|integer|between:1,20000',
            'txt_ct_period_start' => 'required',
            'txt_ct_period_end' => 'required',
            'txt_lift_qty' => 'required',
            'txt_service_bill' => 'required',
            'cbo_bill_type_id' => 'required|integer|between:1,10',
        ];
        $customMessages = [
            'cbo_project_id.required' => 'Select Project.',
            'cbo_project_id.integer' => 'Select Project.',
            'cbo_project_id.between' => 'Select Project.',
            'txt_ct_period_start.required' => 'Start date is required.',
            'txt_ct_period_end.required' => 'End date is required.',
            'txt_lift_qty.required' => 'Lift qty is required.',
            'txt_service_bill.required' => 'Service bill is required.',
            'cbo_bill_type_id.required' => 'Bill type is required.',
            'cbo_bill_type_id.integer' => 'Bill type is required.',
            'cbo_bill_type_id.between' => 'Bill type is required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $data = array();
        $data['project_id'] = $request->cbo_project_id;
        $data['ct_period_start'] = $request->txt_ct_period_start;
        $data['ct_period_end'] = $request->txt_ct_period_end;
        $data['lift_qty'] = $request->txt_lift_qty;
        $data['service_bill'] = $request->txt_service_bill;
        $data['bill_type_id'] = $request->cbo_bill_type_id;
        $data['remark'] = $request->txt_remark;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        DB::table("pro_ct_services")->insert($data);
        return back()->with('success', "Inserted Successfull !");
    }

    public function contract_service_info_edit($id)
    {
        $m_ct_services = DB::table('pro_ct_services')->where('ct_service_id', $id)->first();

        $projects = DB::table("pro_projects")
            ->where('valid', '1')
            ->get();

        $m_bill_type = DB::table("pro_bill_type")
            ->where('valid', '1')
            ->get();

        return view('maintenance.mt_contract_service_info', compact('m_ct_services', 'projects', 'm_bill_type'));
    }
    public function contract_service_info_update(Request $request, $id)
    {
        $rules = [
            'cbo_project_id' => 'required|integer|between:1,20000',
            'txt_ct_period_start' => 'required',
            'txt_ct_period_end' => 'required',
            'txt_lift_qty' => 'required',
            'txt_service_bill' => 'required',
            'cbo_bill_type_id' => 'required|integer|between:1,10',
        ];

        $customMessages = [
            'cbo_project_id.required' => 'Select Project.',
            'cbo_project_id.integer' => 'Select Project.',
            'cbo_project_id.between' => 'Select Project.',
            'txt_ct_period_start.required' => 'Start date is required.',
            'txt_ct_period_end.required' => 'End date is required.',
            'txt_lift_qty.required' => 'Lift qty is required.',
            'txt_service_bill.required' => 'Service bill is required.',
            'cbo_bill_type_id.required' => 'Bill type is required.',
            'cbo_bill_type_id.integer' => 'Bill type is required.',
            'cbo_bill_type_id.between' => 'Bill type is required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $data = array();
        $data['project_id'] = $request->cbo_project_id;
        $data['ct_period_start'] = $request->txt_ct_period_start;
        $data['ct_period_end'] = $request->txt_ct_period_end;
        $data['lift_qty'] = $request->txt_lift_qty;
        $data['service_bill'] = $request->txt_service_bill;
        $data['bill_type_id'] = $request->cbo_bill_type_id;
        $data['remark'] = $request->txt_remark;
        DB::table("pro_ct_services")->where("ct_service_id", $id)->update($data);
        return redirect()->route('mt_contract_service_info')->with('success', "Updated Successfull !");
    }
    // End Contact service 

    //Project Complite
    public function project_complite()
    {

        $m_project = DB::table('pro_projects')
            ->leftJoin('pro_customers', 'pro_projects.customer_id', 'pro_customers.customer_id')
            ->select('pro_projects.*', 'pro_customers.*')
            ->where('pro_projects.valid', '1')
            ->get();

        return view('maintenance.project_complite', compact('m_project'));
    }

    public function project_complite_store(Request $request)
    {
        $rules = [
            'cbo_project_id' => 'required|integer|between:1,20000',
            'txt_pro_handover_date' => 'required',
        ];

        $customMessages = [
            'cbo_project_id.required' => 'Select Project.',
            'cbo_project_id.integer' => 'Select Project.',
            'cbo_project_id.between' => 'Select Project.',
            'txt_pro_handover_date.required' => 'Complite Date is Required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $m_project = DB::table('pro_projects')->where('project_id', $request->cbo_project_id)->first();
        if ($m_project->warranty_end_date == null) {
            $handover_date = $request->txt_pro_handover_date;

            DB::table('pro_projects')->where('project_id', $request->cbo_project_id)->update([
                'handover_date' =>   $handover_date,
                // 'user_id' =>Auth::user()->emp_id(),
            ]);
            return back()->with('success', "Data Updated Successfully!");
        } else {
            return back()->with('warning', "Alredy Updated Successfully!");
        }
    }




    //Task Register
    public function ComplaintRegister()
    {
        $m_complaint_register = DB::table('pro_complaint_register')
            ->join("pro_customers", "pro_customers.customer_id", "pro_complaint_register.customer_id")
            ->join("pro_projects", "pro_projects.project_id", "pro_complaint_register.project_id")
            ->join("pro_lifts", "pro_lifts.lift_id", "pro_complaint_register.lift_id")
            ->select("pro_complaint_register.*", "pro_customers.*", "pro_projects.*", "pro_lifts.*")
            ->where('pro_complaint_register.department_id', '2')
            ->where('pro_complaint_register.valid', '1')
            ->where('pro_complaint_register.status', '1')
            ->get();

        $m_customer = DB::table('pro_customers')
            ->where('valid', '1')
            ->get();

        $m_project = DB::table('pro_projects')
            ->where('valid', '1')
            ->get();

        $m_lift = DB::table('pro_lifts')
            ->where('valid', '1')
            ->get();

        return view('maintenance.mt_complaint_register', compact('m_complaint_register', 'm_customer', 'm_project', 'm_lift'));
    }

    public function complaint_register_store(Request $request)
    {
        $rules = [
            'cbo_customer_id' => 'required|integer|between:1,2000',
            'cbo_project_id' => 'required|integer|between:1,2000',
            'cbo_lift_id' => 'required|integer|between:1,20000',
            'txt_complaint_description' => 'required',
            // 'requirement' => 'required',
        ];

        $customMessages = [
            'cbo_customer_id.required' => 'Select client.',
            'cbo_customer_id.integer' => 'Select client.',
            'cbo_customer_id.between' => 'Select client.',
            'cbo_project_id.required' => 'Select project.',
            'cbo_project_id.integer' => 'Select project.',
            'cbo_project_id.between' => 'Select project.',
            'cbo_lift_id.required' => 'Select lift.',
            'cbo_lift_id.integer' => 'Select lift.',
            'cbo_lift_id.between' => 'Select lift.',
            'txt_complaint_description.required' => 'Complaint description is required.',
        ];

        $this->validate($request, $rules, $customMessages);
        $m_user_id = Auth::user()->emp_id;

        $data = array();
        $data['customer_id'] = $request->cbo_customer_id;
        $data['project_id'] = $request->cbo_project_id;
        $data['lift_id'] = $request->cbo_lift_id;
        $data['complaint_description'] = $request->txt_complaint_description;
        $data['department_id'] = 2; //'2'=>'Maintenance'	
        $data['status'] = 1;
        $data['user_id'] = $m_user_id;
        $data['valid'] = 1;
        $data['entry_time'] = date("h:i:sa");
        $data['entry_date'] = date("Y-m-d");
        DB::table('pro_complaint_register')->insert($data);
        return back()->with('success', "Data Inserted Successfully!");
    }

    public function complaint_register_edit($id)
    {
        $m_complaint_register1 = DB::table('pro_complaint_register')
            ->leftJoin("pro_customers", "pro_customers.customer_id", "pro_complaint_register.customer_id")
            ->leftJoin("pro_projects", "pro_projects.project_id", "pro_complaint_register.project_id")
            ->leftJoin("pro_lifts", "pro_lifts.lift_id", "pro_complaint_register.lift_id")
            ->select("pro_complaint_register.*", "pro_customers.*", "pro_projects.*", "pro_lifts.*")
            ->where('complaint_register_id', $id)
            ->first();

        $m_customer = DB::table('pro_customers')
            ->where('valid', '1')
            ->get();

        $m_project = DB::table('pro_projects')
            ->where('valid', '1')
            ->get();

        $m_lift = DB::table('pro_lifts')
            ->where('valid', '1')
            ->get();

        return view('maintenance.mt_complaint_register', compact('m_complaint_register1', 'm_customer', 'm_project', 'm_lift'));
    }

    public function complaint_register_update(Request $request, $id)
    {
        $rules = [
            'cbo_customer_id' => 'required|integer|between:1,2000',
            'cbo_project_id' => 'required|integer|between:1,2000',
            'cbo_lift_id' => 'required|integer|between:1,20000',
            'txt_complaint_description' => 'required',
            // 'requirement' => 'required',
        ];

        $customMessages = [
            'cbo_customer_id.required' => 'Select client.',
            'cbo_customer_id.integer' => 'Select client.',
            'cbo_customer_id.between' => 'Select client.',
            'cbo_project_id.required' => 'Select project.',
            'cbo_project_id.integer' => 'Select project.',
            'cbo_project_id.between' => 'Select project.',
            'cbo_lift_id.required' => 'Select lift.',
            'cbo_lift_id.integer' => 'Select lift.',
            'cbo_lift_id.between' => 'Select lift.',
            'txt_complaint_description.required' => 'Complaint description is required.',
        ];

        $this->validate($request, $rules, $customMessages);
        $m_user_id = Auth::user()->emp_id;

        $data = array();
        $data['customer_id'] = $request->cbo_customer_id;
        $data['project_id'] = $request->cbo_project_id;
        $data['lift_id'] = $request->cbo_lift_id;
        $data['complaint_description'] = $request->txt_complaint_description;
        DB::table('pro_complaint_register')->where('complaint_register_id', $id)->update($data);
        return redirect()->route('mt_complaint_register')->with('success', "Data Updated Successfully!");
    }

    //End Register


    //task assign
    public function taskassign()
    {
        $m_teams = DB::table("pro_teams")
            ->leftJoin("pro_employee_info", "pro_teams.team_leader_id", "pro_employee_info.employee_id")
            ->select("pro_teams.*", "pro_employee_info.employee_name")
            ->get();
        // return $m_teams;
        $mt_task_assign = DB::table('pro_task_assign')
            ->where('department_id', 2)
            ->where('complete_task', NULL)
            ->where('valid', 1)
            ->get();

        $m_complaint_register = DB::table('pro_complaint_register')
            ->where('department_id', 2)
            ->where('valid', 1)
            ->where('status', 1)
            ->get();

        return view('maintenance.mt_task_assign', compact('m_teams', 'mt_task_assign', 'm_complaint_register'));
    }
    public function task_assign_store(Request $request)
    {
        $rules = [
            'cbo_complain_id' => 'required|required|integer|between:1,2000',
            'cbo_team_id' => 'required|required|integer|between:1,2000',
        ];

        $customMessages = [
            'cbo_complain_id.required' => 'Select complain.',
            'cbo_complain_id.integer' => 'Select complain.',
            'cbo_complain_id.between' => 'Select complain.',
            'cbo_team_id.required' => 'Select team.',
            'cbo_team_id.integer' => 'Select team.',
            'cbo_team_id.between' => 'Select team.',
        ];

        $this->validate($request, $rules, $customMessages);

        $data = array();
        $complain = DB::table("pro_complaint_register")->where("complaint_register_id", $request->cbo_complain_id)->first();
        $teams = DB::table("pro_teams")->where("team_id", $request->cbo_team_id)->first();
        $data['complain_id'] = $request->cbo_complain_id;
        $data['customer_id'] = $complain->customer_id;
        $data['project_id'] = $complain->project_id;
        $data['lift_id'] = $complain->lift_id;
        $data['team_id'] = $request->cbo_team_id;
        $data['team_leader_id'] = $teams->team_leader_id;
        $data['department_id'] = $complain->department_id; //2 ->Maintenance
        $data['remark'] = $request->txt_remark;
        // $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_time'] = date("h:i:sa");
        $data['entry_date'] = date("Y-m-d");
        $task_id = DB::table('pro_task_assign')->insertGetId($data);
        if ($task_id) {
            DB::table('pro_complaint_register')->where('complaint_register_id', $request->cbo_complain_id)
                ->update([
                    'status' => 2,
                ]);

            return redirect()->route('mt_helper_information', $task_id);
        } else {
            return back()->with('warning', "Data Not Found !");
        }
    }

    public function task_assign_edit($id)
    {
        $m_teams = DB::table("pro_teams")
            ->join("pro_employee_info", "pro_teams.team_leader_id", "pro_employee_info.employee_id")
            ->select("pro_teams.*", "pro_employee_info.employee_name")
            ->get();
        $m_task_assign = DB::table('pro_task_assign')->where("task_id", $id)->first();

        $m_complaint_register = DB::table('pro_complaint_register')
            ->where('valid', 1)
            ->where('status', 2)
            ->get();

        return view('maintenance.mt_task_assign', compact('m_teams', 'm_task_assign', 'm_complaint_register'));
    }
    public function task_assign_update(Request $request, $id)
    {
        $rules = [
            'cbo_complain_id' => 'required|required|integer|between:1,2000',
            'cbo_team_id' => 'required|required|integer|between:1,2000',
        ];

        $customMessages = [
            'cbo_complain_id.required' => 'Select complain.',
            'cbo_complain_id.integer' => 'Select complain.',
            'cbo_complain_id.between' => 'Select complain.',
            'cbo_team_id.required' => 'Select team.',
            'cbo_team_id.integer' => 'Select team.',
            'cbo_team_id.between' => 'Select team.',
        ];

        $this->validate($request, $rules, $customMessages);
        $ci_teams = DB::table('pro_teams')->Where('team_id', $request->cbo_team_id)->first();

        $data = array();
        $data['complain_id'] = $request->cbo_complain_id;
        $data['team_id'] = $request->cbo_team_id;
        $data['team_leader_id'] = $ci_teams->team_leader_id;
        $data['remark'] = $request->txt_remark;
        DB::table('pro_task_assign')->where("task_id", $id)->update($data);
        return redirect()->route('mt_task_assign')->with('success', "Updated Successfully!");
    }

    //Add Helper 

    public function helper_information($id)
    {
        $task = DB::table('pro_task_assign')->where("task_id", $id)->first();
        $helper_id = DB::table('pro_helpers')
            ->where('task_id', $id)
            ->pluck('helper_id');

        $data = ["$task->team_leader_id", '00000101', '00000102', '00000103', '00000104', '00000184', '00000185', '00000186'];

        for ($i = 0; $i < count($helper_id); $i++) {
            array_push($data, $helper_id[$i]);
        }

        $helper = DB::table('pro_employee_info')
            ->whereNotIn('employee_id', $data)
            // ->where('desig_id', 15) //15 is helper
            ->get();

        $mt_task_assign = DB::table('pro_task_assign')->where('task_id', $id)->first();
        return view('maintenance.helper_information', compact('mt_task_assign', 'helper'));
    }

    public function add_helper(Request $request, $task_id)
    {
        $rules = [
            'cbo_employee_id' => 'required',
        ];

        $customMessages = [
            'cbo_employee_id.required' => 'Select Helper.',
        ];

        $this->validate($request, $rules, $customMessages);

        $data = array();
        $ms_task_assign = DB::table('pro_task_assign')->where('task_id', $task_id)->first();
        //
        $teams = DB::table("pro_teams")->where("team_id", $ms_task_assign->team_id)->first();
        $data['team_leader_id'] = $teams->team_leader_id;
        $data['team_id'] = $ms_task_assign->team_id;
        //
        $data['task_id'] = $task_id;
        $data['project_id'] = $ms_task_assign->project_id;
        $data['lift_id'] = $ms_task_assign->lift_id;
        $data['complain_id'] = $ms_task_assign->complain_id;
        $data['customer_id'] = $ms_task_assign->customer_id;
        $data['helper_id'] = $request->cbo_employee_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_time'] = date("h:i:s");
        $data['entry_date'] = date("Y-m-d");
        DB::table('pro_helpers')->insert($data);
        return back()->with('success', "Add Successfull !");
    }

    public function task_assign_final()
    {
        return redirect()->route('mt_task_assign');
    }
    //End Task Assign

    //Requisition
    public function requisition()
    {
        $m_teams = DB::table("pro_teams")
            ->leftJoin("pro_employee_info", "pro_teams.team_leader_id", "pro_employee_info.employee_id")
            ->select("pro_teams.*", "pro_employee_info.employee_name")
            ->get();

        $complain_id =  DB::table('pro_task_assign')
            ->where('complete_task', 1)
            ->pluck('complain_id');

        $m_complaint_register = DB::table('pro_complaint_register')
            ->whereNotIn('complaint_register_id', $complain_id)
            ->where('department_id', 2)
            ->where('status', 2)
            ->where('valid', 1)
            ->get();

        $product_group = DB::table('pro_product_group')->get();


        return view('maintenance.mt_requisition', compact('m_teams', 'm_complaint_register', 'product_group'));
    }

    // requisition master
    public function requisition_store(Request $request)
    {

        $rules = [
            'cbo_complain_id' => 'required|integer|between:1,2000',
            'cbo_product_group' => 'required|integer|between:1,2000',
            'cbo_product_sub_group' => 'required|integer|between:1,2000',
            'cbo_product' => 'required|integer|between:1,20000',
            'txt_product_qty' => 'required',
        ];

        $customMessages = [
            'cbo_complain_id.required' => 'Select Complain.',
            'cbo_complain_id.integer' => 'Select Complain.',
            'cbo_complain_id.between' => 'Select Complain.',
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product.',
            'cbo_product.integer' => 'Select Product.',
            'cbo_product.between' => 'Select Product.',
            'txt_product_qty.required' => 'Product Quantity is Required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_user_id = Auth::user()->emp_id;
        $ms_task_assign = DB::table('pro_task_assign')->where('complain_id', $request->cbo_complain_id)->first();

        //12 digit   
        $last_req_no = DB::table('pro_requisition_master')->orderByDesc("requisition_master_id")->first();
        if (isset($last_req_no->req_no)) {
            $req_no = "SOVRQ" . date("my") . str_pad((substr($last_req_no->req_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $req_no = "SOVRQ" . date("my") . "00001";
        }

        //master
        $data = array();
        $data['req_no'] = $req_no;
        $data['complain_id'] = $ms_task_assign->complain_id;
        $data['task_id'] = $ms_task_assign->task_id;
        $data['team_leader_id'] = $ms_task_assign->team_leader_id;
        $data['department_id'] = $ms_task_assign->department_id; // 2-> maintenance
        $data['status'] = 1;
        $data['user_id'] = $m_user_id;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        $req_master_id = DB::table('pro_requisition_master')
            // ->orderBy('requisition_master_id','asc')
            ->insertGetId($data);

        //Details
        $data = array();
        $data['requisition_master_id'] = $req_master_id;
        $data['req_no'] =  $req_no;
        $data['complain_id'] = $ms_task_assign->complain_id;
        $data['task_id'] = $ms_task_assign->task_id;
        $data['team_leader_id'] = $ms_task_assign->team_leader_id;
        $data['department_id'] = $ms_task_assign->department_id; // 2-> maintenance
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['product_qty'] = $request->txt_product_qty;
        $data['status'] = 1;
        $data['user_id'] = $m_user_id;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        DB::table('pro_requisition_details')->insert($data);


        return redirect()->route('mt_requisition_product', $req_master_id);
    }

    // requisition details
    public function requisition_product($id)
    {
        $req_master = DB::table('pro_requisition_master')->where('requisition_master_id', $id)->first();
        $ms_task_assign = DB::table('pro_task_assign')->where('task_id', $req_master->task_id)->first();
        $product_group = DB::table('pro_product_group')->get();
        $req_details = DB::table('pro_requisition_details')->where('requisition_master_id', $id)->get();
        return view('maintenance.requisition_details', compact('ms_task_assign', 'req_master', 'product_group', 'req_details'));
    }
    public function requisition_add_product(Request $request, $id)
    {

        $rules = [
            'cbo_product_group' => 'required|integer|between:1,2000',
            'cbo_product_sub_group' => 'required|integer|between:1,2000',
            'cbo_product' => 'required|integer|between:1,20000',
            'txt_product_qty' => 'required',
        ];

        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product.',
            'cbo_product.integer' => 'Select Product.',
            'cbo_product.between' => 'Select Product.',
            'txt_product_qty.required' => 'Product Quantity is Required.',
        ];

        $this->validate($request, $rules, $customMessages);
        $m_user_id = Auth::user()->emp_id;

        $req_master = DB::table('pro_requisition_master')->where('requisition_master_id', $id)->first();
        // $txt_req_no=$req_master->$req_no;
        // return  $req_master;
        $data = array();
        $data['requisition_master_id'] = $req_master->requisition_master_id;
        $data['req_no'] = $req_master->req_no;
        $data['complain_id'] = $req_master->complain_id;
        $data['task_id'] = $req_master->task_id;
        $data['team_leader_id'] = $req_master->team_leader_id;
        $data['department_id'] = $req_master->department_id;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['product_qty'] = $request->txt_product_qty;
        $data['status'] = 1;
        $data['user_id'] = $m_user_id;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        DB::table('pro_requisition_details')->insert($data);
        return redirect()->route('mt_requisition_product', $id)->with('success', "Add Successfully!");
    }

    public function requisition_finish($id)
    {
        DB::table('pro_requisition_master')->where('requisition_master_id', $id)->update(['status' => 2]);
        DB::table('pro_requisition_details')->where('requisition_master_id', $id)->update(['status' => 2]);

        $req_maaster = DB::table('pro_requisition_master')
            ->where('requisition_master_id', '=', $id)
            ->first();

        DB::table('pro_task_assign')
            ->where('task_id', $req_maaster->task_id)
            ->update(['complete_task' => 2]);

        return redirect()->route('mt_requisition')->with('success', "Add Successfully!");
    }

    //Approved list
    public function RequisitionListApproved()
    {
        $m_user_id = Auth::user()->emp_id;
        $m_requisition_master = DB::table('pro_requisition_master')
            ->where('department_id', 2)
            ->where('valid', 1)
            ->where('status', 2)
            ->get();
        return view('maintenance.mt_requisition_list_approved', compact('m_requisition_master'));
    }

    public function requisition_list_approved_details($id)
    {
        $m_requisition_master = DB::table('pro_requisition_master')
            ->where('requisition_master_id', $id)
            ->where('valid', 1)
            ->where('status', 2)
            ->first();

        $m_requisition_details = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $id)
            ->where('valid', 1)
            ->where('status', 2)
            ->get();
        return view('maintenance.requisition_list_approved_details', compact('m_requisition_details', 'm_requisition_master'));
    }

    public function requisition_list_confirm(Request $request, $id)
    {
        $rules = [
            'txt_approved_qty' => 'required',
        ];

        $customMessages = [
            'txt_approved_qty.required' => 'Approved Quantity is Required.',
        ];

        $this->validate($request, $rules, $customMessages);


        $user = Auth::user();
        $r_details = DB::table('pro_requisition_details')
            ->where('requisition_details_id', '=', $id)
            ->first();

        if ($request->txt_approved_qty > $r_details->product_qty) {
            return back()->with('success', "Approved Quantity Can not getter then product qty.");
        }

        DB::table('pro_requisition_details')
            ->where('requisition_details_id', '=', $id)
            ->update([
                'status' => 3, // 3 - Accept Requisition department head
                'approved_qty' => $request->txt_approved_qty,
                'approved_id' => $user->emp_id,
                'approved_date' => date("Y-m-d"),
                'approved_time' => date("H:i:s"),
            ]);

        //
        $data = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $r_details->requisition_master_id)
            ->where('valid', 1)
            ->count();

        $data2 = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $r_details->requisition_master_id)
            ->where('valid', 1)
            ->where('status', 3)
            ->count();

        if ($data ==  $data2) {
            DB::table('pro_requisition_master')
                ->where('requisition_master_id', '=', $r_details->requisition_master_id)
                ->update([
                    'status' => 3, // 3 - Accept requisition department head
                    'approved_id' => $user->emp_id,
                    'approved_date_time' => date("Y-m-d H:i:s"),
                ]);

            return redirect()->route('mt_requisition_list_approved')->with('success', "Approved Successfully!");
        } else {
            return back()->with('success', "Add Successfully!");
        }
    }

    //Requation Admin Approved
    public function requisition_admin_approved_list()
    {
        $m_requisition_master = DB::table('pro_requisition_master')
            ->where('department_id', 2)
            ->where('status', 3)
            ->where('valid', 1)
            ->get();
        return view('maintenance.mt_requisition_admin_approved_list', compact('m_requisition_master'));
    }

    public function requisition_admin_approved_details($id)
    {
        $m_requisition_master = DB::table('pro_requisition_master')
            ->where('requisition_master_id', $id)
            ->where('valid', 1)
            ->where('status', 3)
            ->first();

        $m_requisition_details = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $id)
            ->where('valid', 1)
            ->where('status', 3)
            ->get();
        return view('maintenance.requisition_admin_approved_details', compact('m_requisition_details', 'm_requisition_master'));
    }

    public function requisition_admin_approved_final(Request $request, $id)
    {
        $rules = [
            'txt_approved_qty' => 'required',
        ];

        $customMessages = [
            'txt_approved_qty.required' => 'Approved Quantity is Required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $user = Auth::user();
        $r_details = DB::table('pro_requisition_details')
            ->where('requisition_details_id', '=', $id)
            ->first();

        if ($request->txt_approved_qty > $r_details->approved_qty) {
            return back()->with('success', "Approved Quantity Can not getter then product qty.");
        }

        DB::table('pro_requisition_details')
            ->where('requisition_details_id', '=', $id)
            ->update([
                'status' => 4, // 4 - Accept Requisition Admin
                'final_approved_qty' => $request->txt_approved_qty,
                'final_approved_id' => $user->emp_id,
                'final_approved_date' => date("Y-m-d"),
                'final_approved_time' => date("H:i:s"),
            ]);

        //
        $data = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $r_details->requisition_master_id)
            ->where('valid', 1)
            ->count();

        $data2 = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $r_details->requisition_master_id)
            ->where('valid', 1)
            ->where('status', 4)
            ->count();

        if ($data ==  $data2) {
            DB::table('pro_requisition_master')
                ->where('requisition_master_id', '=', $r_details->requisition_master_id)
                ->update([
                    'status' => 4, // 4 - Accept requisition Admin
                    'final_approved_id' => $user->emp_id,
                    'final_approved_date_time' => date("Y-m-d H:i:s"),
                ]);

            return redirect()->route('mt_requisition_admin_approved_list')->with('success', "Approved Successfully!");
        } else {
            return back()->with('success', "Add Successfully!");
        }
    }

    //Requation Admin Approved End 


    //End requisition

    //Money receipt
    public function MoneyReceipUser()
    {
        $m_customer = DB::table('pro_customers')
            ->where('valid', '1')
            ->get();
        $m_money_receipt = DB::table('pro_money_receipt')
            ->where('valid', '1')
            ->get();
        return view('maintenance.mt_money_receipt_user', compact('m_customer', 'm_money_receipt'));
    }
    public function MoneyReceiptAdmin()
    {
        $m_customer = DB::table('pro_customers')
            ->where('valid', '1')
            ->get();
        $m_money_receipt = DB::table('pro_money_receipt')
            ->where('valid', '1')
            ->get();
        return view('maintenance.mt_money_receipt_admin', compact('m_customer', 'm_money_receipt'));
    }

    public function money_receipt_store(Request $request)
    {
        $rules = [
            'cbo_customer' => 'required|integer|between:1,2000',
            'txt_collection_date' => 'required',
            'cbo_payment_type' => 'required|integer|between:1,2000',
            'txt_amount' => 'required',
        ];

        $customMessages = [
            'cbo_customer.required' => 'Select Customer.',
            'cbo_customer.integer' => 'Select Customer.',
            'cbo_customer.between' => 'Select Customer.',
            'txt_collection_date.required' => 'Date is required.',
            'cbo_payment_type.required' => 'Payment type is required.',
            'cbo_payment_type.integer' => 'Payment type is required.',
            'cbo_payment_type.between' => 'Payment type is required.',
            'txt_amount.required' => 'Amount is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        if ($request->cbo_payment_type == 2) {
            $rules = [
                'txt_bank' => 'required',
                'txt_dd_no' => 'required',
                'txt_dd_date' => 'required',
            ];

            $customMessages = [
                'txt_bank.required' => 'Bank is required.',
                'txt_dd_no.required' => 'Chq/PO/DD No is required.',
                'txt_dd_date.required' => 'Chq/PO/DD Date is required.',
            ];
            $this->validate($request, $rules, $customMessages);
        }

        //receipt_no
        $mr = DB::table('pro_money_receipt')->orderByDesc("receipt_no")->first();

        if ($mr != null) {
            $store = array();
            $number = str_split($mr->receipt_no);
            for ($i = 0; $i < 2; $i++) {
                $store[$i] = $number[$i];
            }
            $year = implode("", $store);
            $new_year = date("y");

            if ($year  == $new_year) {
                $money_receipt_no =  $mr->receipt_no + 1;
            } else {
                $money_receipt_no = date("ym") . "00001";
            }
        } else {
            $money_receipt_no = date("ym") . "00001";
        }

        $data = array();
        $data['receipt_no'] = $money_receipt_no;
        $data['department_id'] = 2;
        $data['customer_id'] = $request->cbo_customer;
        $data['collection_date'] = $request->txt_collection_date;
        $data['payment_type'] = $request->cbo_payment_type;
        $data['bank'] = $request->txt_bank;
        $data['chq_no'] = $request->txt_dd_no;
        $data['chq_date'] = $request->txt_dd_date;
        $data['paid_amount'] = $request->txt_amount;
        $data['amount_word'] = $request->txt_amount_word;
        $data['remark'] = $request->txt_remark;
        $data['status'] = 1;
        $data['user_id'] = Auth::user()->emp_id;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        DB::table('pro_money_receipt')->insert($data);
        return back()->with('success', "Inserted Successfully!");
    }

    public function money_receipt_edit($id)
    {
        $m_customer = DB::table('pro_customers')
            ->where('valid', '1')
            ->get();

        $m_money_receipt_edit = DB::table('pro_money_receipt')
            ->where('money_receipt_id', $id)
            ->first();

        return view('maintenance.mt_money_receipt_admin', compact('m_customer', 'm_money_receipt_edit'));
    }

    public function money_receipt_update(Request $request, $id)
    {
        $rules = [
            'cbo_customer' => 'required|integer|between:1,2000',
            'txt_collection_date' => 'required',
            'cbo_payment_type' => 'required|integer|between:1,2000',
            'txt_amount' => 'required',
        ];

        $customMessages = [
            'cbo_customer.required' => 'Select Customer.',
            'cbo_customer.integer' => 'Select Customer.',
            'cbo_customer.between' => 'Select Customer.',
            'txt_collection_date.required' => 'Date is required.',
            'cbo_payment_type.required' => 'Payment type is required.',
            'cbo_payment_type.integer' => 'Payment type is required.',
            'cbo_payment_type.between' => 'Payment type is required.',
            'txt_amount.required' => 'Amount is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        if ($request->cbo_payment_type == 2) {
            $rules = [
                'txt_bank' => 'required',
                'txt_dd_no' => 'required',
                'txt_dd_date' => 'required',
            ];

            $customMessages = [
                'txt_bank.required' => 'Bank is required.',
                'txt_dd_no.required' => 'Chq/PO/DD No is required.',
                'txt_dd_date.required' => 'Chq/PO/DD Date is required.',
            ];
            $this->validate($request, $rules, $customMessages);
        }

        $data = array();
        $data['customer_id'] = $request->cbo_customer;
        $data['collection_date'] = $request->txt_collection_date;
        $data['payment_type'] = $request->cbo_payment_type;
        $data['bank'] = $request->txt_bank;
        $data['chq_no'] = $request->txt_dd_no;
        $data['chq_date'] = $request->txt_dd_date;
        $data['paid_amount'] = $request->txt_amount;
        $data['amount_word'] = $request->txt_amount_word;
        $data['remark'] = $request->txt_remark;

        DB::table('pro_money_receipt')
            ->where('money_receipt_id', $id)
            ->update($data);

        return redirect()->route('mt_money_receipt_admin')->with('success', "Updated Successfully!");
    }

    //End Money Receipt



    //quotation
    public function mt_quotation()
    {
        $m_complaint_register = DB::table('pro_complaint_register')
            ->where('department_id', 2)
            ->where('valid', 1)
            ->where('qu_status', null)
            ->get();
        $all_quotation_master = DB::table('pro_maintenance_quotation_master')->where('status', 1)->get();
        return view('maintenance.mt_quotation', compact('all_quotation_master', 'm_complaint_register'));
    }

    public function mt_quotation_store(Request $request)
    {
        $rules = [
            'cbo_complain_id' => 'required',
            'txt_customer' => 'required',
            'txt_date' => 'required',
            'txt_address' => 'required',
            'txt_subject' => 'required',
            'txt_valid_until' => 'required',
        ];
        $customMessages = [
            'txt_customer.required' => 'Customer name required.',
            'txt_date.required' => 'Date required.',
            'txt_address.required' => 'Address required.',
            'txt_subject.required' => 'Subject required.',
            'txt_valid_until.required' => 'Valid Until required.',
            'cbo_complain_id.required' => 'Complain Select.',
        ];

        // $this->validate($request, $rules, $customMessages);

        $quotation = DB::table('pro_maintenance_quotation_master')->orderByDesc("quotation_master_id")->first();
        if (isset($quotation)) {
            $mnum = str_replace("Q", "", $quotation->quotation_master_id);
            $quotation_master_id =  date("Ym") . str_pad((substr($mnum, -5) + 1), 5, '0', STR_PAD_LEFT) . "Q";
        } else {
            $quotation_master_id = date("Ym") . "00001Q";
        }

        //customer
        //if complain ->complain customer
        if ($request->cbo_complain_id) {
            $complain = DB::table('pro_complaint_register')->where('complaint_register_id', $request->cbo_complain_id)->where('valid', 1)->first();
            $customer =  DB::table('pro_customers')
                ->where('customer_id', $complain->customer_id)
                ->first();
            $customer_id =  $customer->customer_id;
        } 
        //Without complain or new customer
        else {
            $customer =  DB::table('pro_customers')
                ->where('customer_name', $request->txt_customer)
                ->where('customer_add', $request->txt_address)
                ->first();
            if ($customer) {
                $customer_id =  $customer->customer_id;
            } else {
                $customer_id = DB::table('pro_customers')->insertGetId([
                    'customer_name' => $request->txt_customer,
                    'customer_add' => $request->txt_address,
                    'customer_email' => $request->txt_email,
                    'customer_phone' => $request->txt_mobile_number,
                    'contact_person' => $request->txt_attention,
                    'entry_date' => date('Y-m-d'),
                    'entry_time' => date('h:i:sa'),
                    'valid' => 1,
                ]);
            }
        }



        $data = array();
        $data['complain_id'] = $request->cbo_complain_id;
        $data['customer_id'] = $customer_id;
        $data['customer_name'] = $request->txt_customer;
        $data['customer_address'] = $request->txt_address;
        $data['customer_mobile'] = $request->txt_mobile_number;
        $data['subject'] = $request->txt_subject;
        $data['offer_valid'] = $request->txt_valid_until;
        $data['reference'] = $request->txt_reference_name;
        $data['reference_mobile'] = $request->txt_reference_number;
        $data['attention'] = $request->txt_attention;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        $data['user_id'] = Auth::user()->emp_id;
        $data['valid'] = 1;
        $data['status'] = 1;
        //
        $data['quotation_master_id'] =  $quotation_master_id;
        $data['quotation_date'] = $request->txt_date;
        //
        $quotation_id = DB::table('pro_maintenance_quotation_master')->insertGetId($data);
        if($quotation_id){
            DB::table('pro_complaint_register')->where('complaint_register_id', $request->cbo_complain_id)->update(['qu_status'=>'1']);
        }

        return redirect()->route('mt_quotation_details', $quotation_id);
    }

    public function mt_quotation_details($id)
    {
        $all_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('quotation_id', $id)
            ->get();

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')->where('quotation_id', $id)->first();
        $product_group = DB::table('pro_product_group')->where('valid', 1)->get();
        return view('maintenance.quotation_details', compact('m_quotation_master', 'product_group', 'all_quotation_details'));
    }

    public function mt_quotation_details_store(Request $request, $id)
    {

        $rules = [
            'cbo_product' => 'required|integer|between:1,99999999',
            'cbo_product_group' => 'required|integer|between:1,99999999',
            'cbo_product_sub_group' => 'required|integer|between:1,99999999',
            'txt_rate' => 'required',
            'txt_quantity' => 'required',
        ];
        $customMessages = [
            'cbo_product.required' => 'Product name required.',
            'cbo_product.integer' => 'Product name required.',
            'cbo_product.between' => 'Product name required.',
            'cbo_product_sub_group.required' => 'Product Sub Group required.',
            'cbo_product_sub_group.integer' => 'Product Sub Group required.',
            'cbo_product_sub_group.between' => 'Product Sub Group required',
            'cbo_product_group.required' => 'Product Group required.',
            'cbo_product_group.integer' => 'Product Group required.',
            'cbo_product_group.between' => 'Product Group required',
            'txt_rate.required' => 'Rate is required.',
            'txt_quantity.required' => 'Quantity is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->first();

        $data = array();
        $data['customer_id'] = $m_quotation_master->customer_id;
        $data['quotation_id'] = $m_quotation_master->quotation_id;
        $data['quotation_master_id'] = $m_quotation_master->quotation_master_id;
        $data['quotation_date'] = $m_quotation_master->quotation_date;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['qty'] = $request->txt_quantity;
        $data['rate'] = $request->txt_rate;
        $data['total'] = $request->txt_rate * $request->txt_quantity;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        $data['user_id'] = Auth::user()->emp_id;
        $data['valid'] = 1;
        $data['status'] = 1;
        DB::table('pro_maintenance_quotation_details')->insert($data);
        return redirect()->route('mt_quotation_details', $id)->with('success', 'Received Successfull !');
    }

    public function mt_quotation_final($id)
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->first();

        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $id)
            ->get();

        return view('maintenance.quotation_details_final', compact('m_quotation_master', 'm_quotation_details'));
    }

    public function mt_quotation_final_store(Request $request, $id)
    {

        $vat = $request->txt_vat == null ? '0' : $request->txt_vat;
        $ait = $request->txt_ait  == null ? '0' : $request->txt_ait;
        $discount = $request->txt_discount == null ? '0' : $request->txt_discount;
        $other = $request->txt_other == null ? '0' : $request->txt_other;

        $data = array();
        $data['vat'] = $vat;
        $data['ait'] = $ait;
        $data['discount'] = $discount;
        $data['other'] = $other;
        $data['sub_total'] = $request->txt_subtotal;
        $data['quotation_total'] = ($request->txt_subtotal + $vat + $ait + $other) - $discount;
        $data['status'] = 2;
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update($data);

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->update(['status' => 2]);

        return redirect()->route('mt_quotation')->with('success', 'Successfull !');
    }

    //edit
    public function mt_quotation_details_edit($id)
    {
        $quotation_details_edit = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_id',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_id',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_details_id', $id)
            ->first();
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')->where('quotation_id', $quotation_details_edit->quotation_id)->first();
        $product_group = DB::table('pro_product_group')->where('valid', 1)->get();
        return view('maintenance.quotation_details', compact('quotation_details_edit', 'product_group', 'm_quotation_master'));
    }
    public function mt_quotation_details_update(Request $request, $id)
    {
        $rules = [
            'cbo_product' => 'required|integer|between:1,99999999',
            'cbo_product_group' => 'required|integer|between:1,99999999',
            'cbo_product_sub_group' => 'required|integer|between:1,99999999',
            'txt_rate' => 'required',
            'txt_quantity' => 'required',
        ];
        $customMessages = [
            'cbo_product.required' => 'Product name required.',
            'cbo_product.integer' => 'Product name required.',
            'cbo_product.between' => 'Product name required.',
            'cbo_product_sub_group.required' => 'Product Sub Group required.',
            'cbo_product_sub_group.integer' => 'Product Sub Group required.',
            'cbo_product_sub_group.between' => 'Product Sub Group required',
            'cbo_product_group.required' => 'Product Group required.',
            'cbo_product_group.integer' => 'Product Group required.',
            'cbo_product_group.between' => 'Product Group required',
            'txt_rate.required' => 'Rate is required.',
            'txt_quantity.required' => 'Quantity is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $data = array();
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['qty'] = $request->txt_quantity;
        $data['rate'] = $request->txt_rate;
        $data['total'] = $request->txt_rate * $request->txt_quantity;

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_details_id', $id)
            ->update($data);

        $get_quotation_id =  DB::table('pro_maintenance_quotation_details')
            ->where('quotation_details_id', $id)
            ->first();
        return redirect()->route('mt_quotation_details', $get_quotation_id->quotation_id)->with('success', 'Updated Successfull !');
    }

    //Quotation approved
    public function mt_quotation_approved()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('status', 2)
            ->get();
        return view('maintenance.mt_quotation_approved', compact('m_quotation_master'));
    }

    public function mt_quotation_approved_next(Request $request)
    {

        $rules = [
            'cbo_quotation_id' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
        ];

        $this->validate($request, $rules, $customMessages);

        return redirect()->route('mt_quotation_approved_details', $request->cbo_quotation_id);
    }
    public function mt_quotation_approved_details($id)
    {

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->first();

        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $id)
            ->where('pro_maintenance_quotation_details.status', "2")
            ->get();

        $m_quotation_approved_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $id)
            ->where('pro_maintenance_quotation_details.status', "3")
            ->get();

        return view('maintenance.mt_quotation_approved_Details', compact('m_quotation_master', 'm_quotation_details', 'm_quotation_approved_details'));
    }

    public function mt_quotation_approved_Details_store(Request $request, $id)
    {

        $rules = [
            'txt_approved_rate' => 'required',
            'txt_approved_qty' => 'required',
        ];
        $customMessages = [
            'txt_approved_rate.required' => 'Rate is required.',
            'txt_approved_qty.required' => 'Quantity is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_quotation_details =  DB::table('pro_maintenance_quotation_details')
            ->where('quotation_details_id', $id)
            ->first();


        $data = array();
        $data['approved_qty'] = $request->txt_approved_qty;
        $data['approved_rate'] = $request->txt_approved_rate;
        $data['approved_total'] = $request->txt_approved_rate * $request->txt_approved_qty;
        $data['approved_id'] = Auth::user()->emp_id;
        $data['status'] = "3";

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_details_id', $id)
            ->update($data);

        return back()->with('success', 'Successfull !');
    }

    public function mt_quotation_approved_final(Request $request, $id)
    {
        $vat = $request->txt_vat == null ? '0' : $request->txt_vat;
        $ait = $request->txt_ait  == null ? '0' : $request->txt_ait;
        $discount = $request->txt_discount == null ? '0' : $request->txt_discount;
        $other = $request->txt_other == null ? '0' : $request->txt_other;

        $data = array();
        $data['approved_vat'] = $vat;
        $data['approved_ait'] =   $ait;
        $data['approved_discount'] =  $discount;
        $data['approved_other'] =  $other;
        $data['approved_sub_total'] = $request->txt_subtotal;
        $data['approved_quotation_total'] = ($request->txt_subtotal + $vat + $ait + $other) - $discount;
        $data['status'] = 3;
        $data['approved_id'] = Auth::user()->emp_id;
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update($data);

        return redirect()->route('mt_quotation_approved');
    }

    //Quotation MGM Approved 
    public function mt_quotation_approved_mgm()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('status', 3)
            ->get();
        return view('maintenance.mt_quotation_approved_mgm', compact('m_quotation_master'));
    }



    public function mt_quotation_approved_details_mgm(Request $request)
    {

        $rules = [
            'cbo_quotation_id' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->first();

        $m_quotation_approved_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $request->cbo_quotation_id)
            ->where('pro_maintenance_quotation_details.status', "3")
            ->get();

        return view('maintenance.mt_quotation_approved_details_mgm', compact('m_quotation_master', 'm_quotation_approved_details'));
    }

    public function mt_quotation_accept($id)
    {
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update([
                'approved_mgm_id' => Auth::user()->emp_id,
                'status' => 4,
            ]);

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->update([
                'approved_mgm_id' => Auth::user()->emp_id,
                'status' => 4,
            ]);

        return redirect()->route('rpt_mt_quotation_view', $id);
    }


    public function mt_quotation_reject($id)
    {
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update([
                'approved_mgm_id' => Auth::user()->emp_id,
                'status' => 5,
            ]);

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->update([
                'approved_mgm_id' => Auth::user()->emp_id,
                'status' => 5,
            ]);

        $Q_master =  DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->first();
         DB::table('pro_complaint_register')->where('complaint_register_id', $Q_master->complain_id)->update(['qu_status'=>null]);
        return redirect()->route('mt_quotation_approved_mgm');
        
    }


    public function mt_quotation_customer_approved()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('status', 4)
            ->where('customer_status', null)
            ->get();

        return view('maintenance.mt_quotation_customer_approved', compact('m_quotation_master'));
    }

    public function mt_customer_quotation_approved_edit(Request $request)
    {
        $rules = [
            'cbo_quotation_id' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->first();

        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $request->cbo_quotation_id)
            ->where('pro_maintenance_quotation_details.customer_status', null)
            ->get();

        $m_quotation_approved_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $request->cbo_quotation_id)
            ->where('pro_maintenance_quotation_details.customer_status', 1)
            ->get();

        return view('maintenance.mt_customer_quotation_approved_confirm', compact('m_quotation_master', 'm_quotation_details', 'm_quotation_approved_details'));
    }

    public function mt_customer_quotation_approved_update(Request $request, $id)
    {
        $rules = [
            'txt_approved_rate' => 'required',
            'txt_approved_qty' => 'required',
        ];
        $customMessages = [
            'txt_approved_rate.required' => 'Rate is required.',
            'txt_approved_qty.required' => 'Quantity is required.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_quotation_details =  DB::table('pro_maintenance_quotation_details')
            ->where('quotation_details_id', $id)
            ->first();


        $data = array();
        $data['approved_qty'] = $request->txt_approved_qty;
        $data['approved_rate'] = $request->txt_approved_rate;
        $data['approved_total'] = $request->txt_approved_rate * $request->txt_approved_qty;
        $data['approved_id'] = Auth::user()->emp_id;
        $data['customer_status'] = "1";

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_details_id', $id)
            ->update($data);

        return back()->with('success', 'Successfull !');
    }

    public function mt_customer_quotation_approved_final(Request $request, $id)
    {
        $vat = $request->txt_vat == null ? '0' : $request->txt_vat;
        $ait = $request->txt_ait  == null ? '0' : $request->txt_ait;
        $discount = $request->txt_discount == null ? '0' : $request->txt_discount;
        $other = $request->txt_other == null ? '0' : $request->txt_other;

        $data = array();
        $data['approved_vat'] = $vat;
        $data['approved_ait'] =   $ait;
        $data['approved_discount'] =  $discount;
        $data['approved_other'] =  $other;
        $data['approved_sub_total'] = $request->txt_subtotal;
        $data['approved_quotation_total'] = ($request->txt_subtotal + $vat + $ait + $other) - $discount;
        $data['customer_status'] = 1;
        $data['confirm_approved_id'] = Auth::user()->emp_id;
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update($data);

        return redirect()->route('mt_quotation_approved');
    }

    public function mt_quotation_customer_approved_mgm()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('customer_status', 1)
            ->get();
        return view('maintenance.mt_quotation_customer_approved_mgm', compact('m_quotation_master'));
    }

    public function mt_quotation_customer_approved_details_mgm(Request $request)
    {

        $rules = [
            'cbo_quotation_id' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
        ];

        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->first();

        $m_quotation_approved_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $request->cbo_quotation_id)
            ->where('pro_maintenance_quotation_details.customer_status', "1")
            ->get();

        return view('maintenance.mt_quotation_customer_approved_details_mgm', compact('m_quotation_master', 'm_quotation_approved_details'));
    }

    public function mt_customer_quotation_accept($id)
    {
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update([
                'mgm_confirm_approved_id' => Auth::user()->emp_id,
                'customer_status' => 2,
            ]);

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->update([
                'mgm_confirm_approved_id' => Auth::user()->emp_id,
                'customer_status' => 2,
            ]);

        return redirect()->route('rpt_mt_quotation_view', $id);
    }

    public function mt_customer_quotation_reject($id)
    {
        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->update([
                'mgm_confirm_approved_id' => Auth::user()->emp_id,
                'customer_status' => 3,
            ]);

        DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->update([
                'mgm_confirm_approved_id' => Auth::user()->emp_id,
                'customer_status' => 3,
            ]);

        return redirect()->route('mt_quotation_approved_mgm');
    }

    //Ajax Quotation
    public function GetMtQuotationProductSubGroup($id)
    {
        $data = DB::table('pro_product_sub_group')
            ->where('pg_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }
    public function GetMtQuotationProduct($id, $quotation_id)
    {
        $product_id = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->pluck('product_id');

        $data = DB::table('pro_product')
            ->whereNotIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetMtProductRate($product_id)
    {
        $product = DB::table('pro_product')
            ->where('product_id', $product_id)
            ->where('valid', 1)
            ->first();
        $unit = DB::table('pro_units')->where('unit_id', $product->unit_id)->first();

        $pu_product = DB::table('pro_purchase_details')
            ->where('product_id', $product_id)
            ->where('valid', 1)
            ->orderByDesc('entry_date')
            ->first();

        if ($pu_product) {
            $price = $pu_product->approved_rate;
            $qty = $pu_product->approved_qty;
            $vat_rate = $product->vat_rate;
            $vat = ($price * $vat_rate) / 100;
            $rate = $price + $vat;

            $data = array();
            $data['rate'] = $rate;
            $data['qty'] = $qty;
            $data['unit_name'] = $unit->unit_name;
            return response()->json($data);
        } else {
            $data = array();
            $data['rate'] = '';
            $data['qty'] = '';
            $data['unit_name'] = $unit->unit_name;
            return response()->json($data);
        }
    }

    public function GetCustomer()
    {
        $data = DB::table('pro_customers')
            ->orderByDesc('customer_id')
            ->get();
        return response()->json($data);
    }

    public function GetCustomerDetails($complain_id)
    {

        $complain = DB::table('pro_complaint_register')->where('complaint_register_id', $complain_id)->where('valid', 1)->first();
        $customer = DB::table('pro_customers')->where('customer_id', $complain->customer_id)->where('valid', 1)->first();
        $customer == null ? '0' : $customer;
        return response()->json($customer);
    }

    public function GetApprovedQuotation($id)
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->leftJoin('pro_employee_info', 'pro_maintenance_quotation_master.approved_mgm_id', 'pro_employee_info.employee_id')
            ->select('pro_maintenance_quotation_master.*', 'pro_employee_info.employee_name')
            ->where('pro_maintenance_quotation_master.quotation_id', $id)
            // ->where('pro_maintenance_quotation_master.status', 3)
            ->first();
        return response()->json($m_quotation_master);
    }

    //RPT Quotation
    public function rpt_mt_quotation_list()
    {
        return view('maintenance.rpt_mt_quotation_list');
    }
    public function GetMtRptQuotationList()
    {
        $data = DB::table('pro_maintenance_quotation_master')
            // ->leftJoin('pro_customers', 'pro_maintenance_quotation_master.customer_id', 'pro_customers.customer_id')
            ->leftJoin('pro_employee_info', 'pro_maintenance_quotation_master.approved_id', 'pro_employee_info.employee_id')
            ->leftJoin('pro_employee_info as mgm', 'pro_maintenance_quotation_master.approved_mgm_id', 'mgm.employee_id')
            ->select('pro_maintenance_quotation_master.*', 'pro_employee_info.employee_name as approved', 'mgm.employee_name as mgm_name')
            ->whereIn('pro_maintenance_quotation_master.status', ['3', '4'])
            ->get();
        return response()->json($data);
    }
    public function rpt_mt_quotation_view($id)
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')->where('quotation_id', $id)->first();
        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_id',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_id',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $id)
            ->get();
        return view('maintenance.rpt_quotation_view', compact('m_quotation_master', 'm_quotation_details'));
    }

    public function rpt_mt_quotation_print($id)
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')->where('quotation_id', $id)->first();
        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_quotation_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_quotation_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_quotation_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_quotation_details.*',
                'pro_product.*',
                'pro_product_group.pg_id',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_id',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_quotation_details.quotation_id', $id)
            ->get();
        return view('maintenance.rpt_quotation_print', compact('m_quotation_master', 'm_quotation_details'));
    }
    //End  quotation


    // WorkOrder
    public function mt_work_order()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('status', 2)
            ->where('wo_status', null)
            ->get();
        return view('maintenance.mt_work_order', compact('m_quotation_master'));
    }

    public function mt_work_order_store(Request $request)
    {
        $rules = [
            'cbo_quotation_id' => 'required',
            'cbo_product_group' => 'required',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_quantity' => 'required',
            'txt_rate' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_quantity.required' => 'QTY is required!',
            'txt_rate.required' => 'Rate is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->where('status', 2)
            ->first();

        $product = DB::table('pro_product')
            ->where('product_id', $request->cbo_product)
            ->where('valid', 1)
            ->first();

        $last_inv_no = DB::table('pro_maintenance_work_order_master')->orderByDesc("wo_invoice_no")->first();
        if (isset($last_inv_no->wo_invoice_no)) {
            $wo_invoice_no = "SEWO" . date("my") . str_pad((substr($last_inv_no->wo_invoice_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $wo_invoice_no = "SEWO" . date("my") . "00001";
        }

        $master_id = DB::table('pro_maintenance_work_order_master')->insertGetId([
            'wo_invoice_no' => $wo_invoice_no,
            'quotation_id' => $m_quotation_master->quotation_id,
            'quotation_master_id' => $m_quotation_master->quotation_master_id,
            'quotation_date' => $m_quotation_master->quotation_date,
            'customer_address' => $m_quotation_master->customer_address,
            'customer_id' => $m_quotation_master->customer_id,
            'customer_name' => $m_quotation_master->customer_name,
            'reference' => $m_quotation_master->reference,
            'user_id' => Auth::user()->emp_id,
            'status' => 1,
            'valid' => 1,
            'entry_date' => date("Y-m-d"),
            'entry_time' => date("h:i:sa"),
        ]);

        $data = array();
        $data['wo_master_id'] = $master_id;
        $data['wo_invoice_no'] = $wo_invoice_no;
        $data['quotation_id'] = $m_quotation_master->quotation_id;
        $data['quotation_master_id'] = $m_quotation_master->quotation_master_id;
        $data['quotation_date'] =  $m_quotation_master->quotation_date;
        $data['customer_id'] =  $m_quotation_master->customer_id;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['unit_id'] = $product->unit_id;
        $data['qty'] = $request->txt_quantity;
        $data['rate'] = $request->txt_rate;
        $data['total'] = ($request->txt_quantity * $request->txt_rate);
        $data['remark'] = $request->txt_remark;
        $data['user_id'] = Auth::user()->emp_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        DB::table('pro_maintenance_work_order_details')->insert($data);
        return redirect()->route('mt_work_order_details', $wo_invoice_no);
    }

    public function mt_work_order_details($id)
    {
        $wo_master = DB::table('pro_maintenance_work_order_master')->where("wo_invoice_no", $id)->first();

        $wo_details = DB::table('pro_maintenance_work_order_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_work_order_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_work_order_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->leftJoin('pro_product', 'pro_maintenance_work_order_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_work_order_details.*',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_name',
                'pro_product.product_name',
            )
            ->where("pro_maintenance_work_order_details.wo_invoice_no", $id)
            ->get();

        $product_id = DB::table('pro_maintenance_work_order_details')->where("wo_invoice_no", $id)->pluck('product_id');

        $pg_id = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $wo_master->quotation_id)
            ->whereNotIn('product_id', $product_id)
            ->pluck('pg_id');

        $product_group = DB::table('pro_product_group')
            ->whereIn('pg_id', $pg_id)
            ->where('valid', 1)
            ->get();

        return view('maintenance.mt_work_order_details', compact('wo_master', 'wo_details', 'product_group'));
    }

    public function mt_work_order_details_store(Request $request, $id)
    {
        $rules = [
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_quantity' => 'required',
            'txt_rate' => 'required',
        ];
        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_quantity.required' => 'QTY is required!',
            'txt_rate.required' => 'Rate is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_work_order_master')
            ->where('wo_master_id', $id)
            ->first();

        $product = DB::table('pro_product')
            ->where('product_id', $request->cbo_product)
            ->where('valid', 1)
            ->first();

        $data = array();
        $data['wo_master_id'] = $m_quotation_master->wo_master_id;
        $data['wo_invoice_no'] = $m_quotation_master->wo_invoice_no;
        $data['quotation_id'] = $m_quotation_master->quotation_id;
        $data['quotation_master_id'] = $m_quotation_master->quotation_master_id;
        $data['quotation_date'] =  $m_quotation_master->quotation_date;
        $data['customer_id'] =  $m_quotation_master->customer_id;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['unit_id'] = $product->unit_id;
        $data['qty'] = $request->txt_quantity;
        $data['rate'] = $request->txt_rate;
        $data['total'] = ($request->txt_quantity * $request->txt_rate);
        $data['remark'] = $request->txt_remark;
        $data['user_id'] = Auth::user()->emp_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        DB::table('pro_maintenance_work_order_details')->insert($data);
        return back()->with('success', 'Data Add Successfull');
    }

    public function mt_work_order_final($id)
    {
        $wo_master = DB::table('pro_maintenance_work_order_master')->where("wo_master_id", $id)->first();

        DB::table('pro_maintenance_work_order_master')->where("wo_master_id", $id)->update(['status' => 2]);
        DB::table('pro_maintenance_work_order_details')->where("wo_master_id", $id)->update(['status' => 2]);
        DB::table('pro_maintenance_quotation_master')->where("quotation_id", $wo_master->quotation_id)->update(['wo_status' => 1]);
        DB::table('pro_maintenance_quotation_details')->where("quotation_id", $wo_master->quotation_id)->update(['wo_status' => 1]);

        return redirect()->route('mt_work_order');
    }
    //Ajax Work order
    public function GetMtQuotation($id)
    {

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $id)
            ->where('status', 2)
            ->first();

        return response()->json($m_quotation_master);
    }


    public function GetMtQuotationGroup($id)
    {
        $pg_id = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->pluck('pg_id');
        $data = DB::table('pro_product_group')
            ->whereIn('pg_id', $pg_id)
            ->where('valid', 1)
            ->get();

        return response()->json($data);
    }


    public function GetMtWorkOderProductSubGroup($id, $quotation_id)
    {
        $pg_sub_id =  DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->pluck('pg_sub_id');

        $data = DB::table('pro_product_sub_group')
            ->whereIn('pg_sub_id', $pg_sub_id)
            ->where('pg_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetMtWorkOderProduct($id, $quotation_id)
    {
        $product_id = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->pluck('product_id');

        $data = DB::table('pro_product')
            ->whereIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetMtWorkOderDetailsProductSubGroup($id, $quotation_id, $wo_id)
    {
        $product_id = DB::table('pro_maintenance_work_order_details')->where("wo_master_id", $wo_id)->pluck('product_id');
        $pg_sub_id =  DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->whereNotIn('product_id', $product_id)
            ->pluck('pg_sub_id');

        $data = DB::table('pro_product_sub_group')
            ->whereIn('pg_sub_id', $pg_sub_id)
            ->where('pg_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetMtWorkOderDetailsProduct($id, $quotation_id, $wo_id)
    {
        $wo_product_id = DB::table('pro_maintenance_work_order_details')->where("wo_master_id", $wo_id)->pluck('product_id');
        $product_id = DB::table('pro_maintenance_quotation_details')
            ->whereNotIn('product_id', $wo_product_id)
            ->where('quotation_id', $quotation_id)
            ->pluck('product_id');
        $data = DB::table('pro_product')
            ->whereIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }


    public function GetMtWorkOderProductRate($id, $quotation_id)
    {
        $data = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->where('product_id', $id)
            ->first();

        return response()->json($data);
    }

    //End WorkOrder

    // Delivery challan
    public function mt_delivery_challan()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('customer_status', 2)
            ->where('dc_status', null)
            ->get();
        return view('maintenance.mt_delivery_challan', compact('m_quotation_master'));
    }

    public function mt_delivery_challan_store(Request $request)
    {
        $rules = [
            'cbo_quotation_id' => 'required',
            'cbo_product_group' => 'required',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_quantity' => 'required',
            'txt_dcm_date' => 'required',
            'cbo_address' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_quantity.required' => 'QTY is required!',
            'txt_dcm_date.required' => 'DCM Date is required!',
            'cbo_address.required' => 'Address is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->first();

        $product = DB::table('pro_product')
            ->where('product_id', $request->cbo_product)
            ->where('valid', 1)
            ->first();

        // $last_inv_no = DB::table('pro_maintenance_delivery_chalan_master')->orderByDesc("chalan_no")->first();
        // if (isset($last_inv_no->chalan_no)) {
        //     $chalan_no = "SOVDC" . date("my") . str_pad((substr($last_inv_no->chalan_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        // } else {
        //     $chalan_no = "SOVDC" . date("my") . "00001";
        // }

        $chalan_no = str_replace("Q", "C", $m_quotation_master->quotation_master_id);

        $master_id = DB::table('pro_maintenance_delivery_chalan_master')->insertGetId([
            'chalan_no' => $chalan_no,
            'dcm_date' => $request->txt_dcm_date,
            'quotation_id' => $m_quotation_master->quotation_id,
            'quotation_master_id' => $m_quotation_master->quotation_master_id,
            'quotation_date' => $m_quotation_master->quotation_date,
            'complain_id' => $m_quotation_master->complain_id,
            'customer_id' => $m_quotation_master->customer_id,
            'customer_name' => $m_quotation_master->customer_name,
            'delivery_address' => $request->cbo_address,
            'reference' => $m_quotation_master->reference,
            'user_id' => Auth::user()->emp_id,
            'status' => 1,
            'valid' => 1,
            'entry_date' => date("Y-m-d"),
            'entry_time' => date("h:i:s"),
        ]);


        //
        $m_quotation_details = DB::table("pro_maintenance_quotation_details")
            ->where('quotation_id', $m_quotation_master->quotation_id)
            ->where('product_id', $request->cbo_product)
            ->first();
        $quotation_qty = $m_quotation_details->approved_qty;
        $delivery_qty = ($m_quotation_details->dc_qty == null ? '0' : $m_quotation_details->dc_qty) + $request->txt_quantity;
        if ($delivery_qty > $quotation_qty) {
            return back()->with('warning', "Deliver Qty Getter Then Quotation Qty ($delivery_qty > $quotation_qty)");
        } else {
            $data = array();
            $data['delivery_chalan_master_id'] = $master_id;
            $data['chalan_no'] = $chalan_no;
            $data['quotation_id'] = $m_quotation_master->quotation_id;
            $data['quotation_master_id'] = $m_quotation_master->quotation_master_id;
            $data['quotation_date'] =  $m_quotation_master->quotation_date;
            $data['customer_id'] = $m_quotation_master->customer_id;
            // $data['quotation_qty'] = $quotation_qty;
            $data['pg_id'] = $request->cbo_product_group;
            $data['pg_sub_id'] = $request->cbo_product_sub_group;
            $data['product_id'] = $request->cbo_product;
            $data['unit_id'] = $product->unit_id;
            $data['del_qty'] = $request->txt_quantity;
            $data['remark'] = $request->txt_remark;
            $data['user_id'] = Auth::user()->emp_id;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:s");
            DB::table('pro_maintenance_delivery_chalan_details')->insert($data);

            DB::table('pro_maintenance_quotation_details')
                ->where('quotation_id', $m_quotation_master->quotation_id)
                ->where('product_id', $request->cbo_product)
                ->update(['dc_qty' => $delivery_qty]);

            //quotationt -Details product update
            $p_quotation_details = DB::table("pro_maintenance_quotation_details")
                ->where('quotation_id', $m_quotation_master->quotation_id)
                ->where('product_id', $request->cbo_product)
                ->first();
            if ($p_quotation_details->approved_qty == $p_quotation_details->dc_qty) {
                DB::table("pro_maintenance_quotation_details")
                    ->where('quotation_id', $m_quotation_master->quotation_id)
                    ->where('product_id', $request->cbo_product)
                    ->update(['dc_status' => 1]);
            }

            // quotationt -master update
            $data1 =  DB::table("pro_maintenance_quotation_details")
                ->where('quotation_id', $m_quotation_master->quotation_id)
                ->where('dc_status', 1)
                ->count();
            $data2 = DB::table("pro_maintenance_quotation_details")
                ->where('quotation_id', $m_quotation_master->quotation_id)
                ->count();

            if ($data1 == $data2) {
                DB::table("pro_maintenance_quotation_master")
                    ->where('quotation_id', $m_quotation_master->quotation_id)
                    ->update(['dc_status' => 1]);
            }
            return redirect()->route('mt_delivery_challan_details', $chalan_no);
        }
    }

    public function mt_delivery_challan_details($id)
    {
        $d_challan = DB::table("pro_maintenance_delivery_chalan_master")->where("chalan_no", $id)->first();

        $d_challan_details = DB::table("pro_maintenance_delivery_chalan_details")
            ->where("chalan_no", $id)
            ->where("status", 1)
            ->get();

        $d_product_id = DB::table("pro_maintenance_delivery_chalan_details")->where("chalan_no", $id)->pluck('product_id');
        $pg_id = DB::table("pro_maintenance_quotation_details")->where('quotation_id', $d_challan->quotation_id)->whereNotIn('product_id', $d_product_id)->where('dc_status', null)->pluck('pg_id');
        $product_group = DB::table('pro_product_group')->whereIn('pg_id', $pg_id)->get();

        return view('maintenance.delivery_challan_details', compact('d_challan', 'd_challan_details', 'product_group'));
    }

    public function mt_delivery_challan_details_store(Request $request, $id)
    {
        $rules = [
            'cbo_product_group' => 'required',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_quantity' => 'required',
        ];
        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_quantity.required' => 'QTY is required!',
        ];
        $this->validate($request, $rules, $customMessages);


        $d_challan = DB::table("pro_maintenance_delivery_chalan_master")->where("chalan_no", $id)->first();
        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $d_challan->quotation_id)
            ->where('product_id', $request->cbo_product)
            ->first();

        $product = DB::table('pro_product')
            ->where('product_id', $request->cbo_product)
            ->where('valid', 1)
            ->first();

        $quotation_qty = $m_quotation_details->approved_qty;
        $delivery_qty = ($m_quotation_details->dc_qty == null ? '0' : $m_quotation_details->dc_qty) + $request->txt_quantity;
        if ($delivery_qty > $quotation_qty) {
            return back()->with('warning', "Deliver Qty Getter Then Quotation Qty ($delivery_qty > $quotation_qty)");
        } else {

            $data = array();
            $data['delivery_chalan_master_id'] = $d_challan->delivery_chalan_master_id;
            $data['chalan_no'] = $d_challan->chalan_no;
            $data['quotation_id'] = $d_challan->quotation_id;
            $data['quotation_master_id'] = $d_challan->quotation_master_id;
            $data['quotation_date'] =  $d_challan->quotation_date;
            $data['customer_id'] = $d_challan->customer_id;
            // $data['quotation_qty'] = $quotation_qty;
            $data['pg_id'] = $request->cbo_product_group;
            $data['pg_sub_id'] = $request->cbo_product_sub_group;
            $data['product_id'] = $request->cbo_product;
            $data['unit_id'] = $product->unit_id;
            $data['del_qty'] = $request->txt_quantity;
            $data['remark'] = $request->txt_remark;
            $data['user_id'] = Auth::user()->emp_id;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:s");
            DB::table('pro_maintenance_delivery_chalan_details')->insert($data);
            DB::table('pro_maintenance_quotation_details')
                ->where('quotation_id', $d_challan->quotation_id)
                ->where('product_id', $request->cbo_product)
                ->update(['dc_qty' => $delivery_qty]);

            //quotationt -Details product update
            $p_quotation_details = DB::table("pro_maintenance_quotation_details")
                ->where('quotation_id', $d_challan->quotation_id)
                ->where('product_id', $request->cbo_product)
                ->first();
            if ($p_quotation_details->approved_qty == $p_quotation_details->dc_qty) {
                DB::table("pro_maintenance_quotation_details")->where('quotation_id', $d_challan->quotation_id)->where('product_id', $request->cbo_product)->update(['dc_status' => 1]);
            }

            // //quotationt -master update
            $data1 =  DB::table("pro_maintenance_quotation_details")
                ->where('quotation_id', $d_challan->quotation_id)
                ->where('dc_status', 1)
                ->count();
            $data2 = DB::table("pro_maintenance_quotation_details")
                ->where('quotation_id', $d_challan->quotation_id)
                ->count();

            if ($data1 == $data2) {
                DB::table("pro_maintenance_quotation_master")->where('quotation_id', $d_challan->quotation_id)->update(['dc_status' => 1]);
            }
            return back()->with('success', "Add Successfull");
        }
    }

    public function mt_delivery_challan_final($id)
    {
        DB::table("pro_maintenance_delivery_chalan_master")->where('chalan_no', $id)->update(['status' => 2]);
        DB::table("pro_maintenance_delivery_chalan_details")->where('chalan_no', $id)->update(['status' => 2]);
        return redirect()->route('rpt_mt_delivery_challan_view', $id);
    }

    public function rpt_mt_delivery_challan()
    {
        $d_challan =  DB::table("pro_maintenance_delivery_chalan_master")->where('status', 2)->get();
        return view('maintenance.rpt_mt_delivery_challan', compact('d_challan'));
    }

    public function rpt_mt_delivery_challan_view($id)
    {
        $d_challan =  DB::table("pro_maintenance_delivery_chalan_master")->where('chalan_no', $id)->first();
        $d_details =  DB::table("pro_maintenance_delivery_chalan_details")->where('chalan_no', $id)->get();
        return view('maintenance.rpt_mt_delivery_challan_view', compact('d_challan', 'd_details'));
    }
    public function rpt_mt_delivery_challan_print($id)
    {
        $d_challan =  DB::table("pro_maintenance_delivery_chalan_master")->where('chalan_no', $id)->first();
        $d_details =  DB::table("pro_maintenance_delivery_chalan_details")->where('chalan_no', $id)->get();
        return view('maintenance.rpt_mt_delivery_challan_print', compact('d_challan', 'd_details'));
    }

    //Ajx Delivery challan
    public function GetDcQuotation($id)
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->leftJoin('pro_employee_info', 'pro_maintenance_quotation_master.user_id', 'pro_employee_info.employee_id')
            ->select('pro_maintenance_quotation_master.*', 'pro_employee_info.employee_name')
            ->where('pro_maintenance_quotation_master.quotation_id', $id)
            // ->where('pro_maintenance_quotation_master.status', 3)
            ->first();
        return response()->json($m_quotation_master);
    }
    public function GetDcQuotationGroup($id)
    {
        $pg_id = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $id)
            ->pluck('pg_id');
        $data = DB::table('pro_product_group')
            ->whereIn('pg_id', $pg_id)
            ->where('valid', 1)
            ->get();

        return response()->json($data);
    }

    public function GetDcProductSubGroup($id, $quotation_id)
    {
        $pg_sub_id =  DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->where('dc_status', null)
            ->pluck('pg_sub_id');

        $data = DB::table('pro_product_sub_group')
            ->whereIn('pg_sub_id', $pg_sub_id)
            ->where('pg_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetDcProduct($id, $quotation_id)
    {
        $product_id = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->where('dc_status', null)
            ->pluck('product_id');

        $data = DB::table('pro_product')
            ->whereIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetDcProductDetails($id, $quotation_id)
    {
        $Quotation = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $quotation_id)
            ->where('product_id', $id)
            ->first();
        $qu_qty = $Quotation->approved_qty == null ? '0' : $Quotation->approved_qty;
        $dc_qty = $Quotation->dc_qty == null ? '0' : $Quotation->dc_qty;

        $product = DB::table('pro_product')
            ->where('product_id', $id)
            ->first();
        $unit = DB::table('pro_units')
            ->where('unit_id', $product->unit_id)
            ->first();
        $unit_name = $unit == null ? '' : $unit->unit_name;


        $data = array();
        $data['qu_qty'] = $qu_qty;
        $data['balance'] = $dc_qty;
        $data['qty'] = $qu_qty - $dc_qty;
        $data['unit_name'] =  $unit_name;
        return response()->json($data);
    }

    public function GetDcDetailsProductSubGroup($id, $quotation_id, $dc_id)
    {
        $d_product_id = DB::table("pro_maintenance_delivery_chalan_details")->where("chalan_no", $dc_id)->pluck('product_id');
        $pg_sub_id = DB::table("pro_maintenance_quotation_details")
            ->where('quotation_id', $quotation_id)
            ->whereNotIn('product_id', $d_product_id)
            ->where('dc_status', null)
            ->pluck('pg_sub_id');

        $data = DB::table('pro_product_sub_group')
            ->whereIn('pg_sub_id', $pg_sub_id)
            ->where('pg_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    public function GetDcDetailsProduct($id, $quotation_id, $dc_id)
    {
        $d_product_id = DB::table("pro_maintenance_delivery_chalan_details")->where("chalan_no", $dc_id)->pluck('product_id');
        $product_id = DB::table("pro_maintenance_quotation_details")
            ->where('quotation_id', $quotation_id)
            ->whereNotIn('product_id', $d_product_id)
            ->where('dc_status', null)
            ->pluck('product_id');

        $data = DB::table('pro_product')
            ->whereIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->where('valid', 1)
            ->get();
        return response()->json($data);
    }

    //End Delivery challan


    //Bill
    public function mt_bill()
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('customer_status', 2)
            ->where('bill_status', null)
            ->get();
        return view('maintenance.mt_bill', compact('m_quotation_master'));
    }

    public function mt_bill_store(Request $request)
    {
        $rules = [
            'cbo_quotation_id' => 'required',
            'txt_subject' => 'required',
        ];
        $customMessages = [
            'cbo_quotation_id.required' => 'Select Quotation.',
            'txt_subject.required' => 'Subject is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->first();

        // $last_inv_no = DB::table('pro_maintenance_bill_master')->orderByDesc("maintenance_bill_master_no")->first();
        // if (isset($last_inv_no->maintenance_bill_master_no)) {
        //     $maintenance_bill_master_no = "SOVMB" . date("my") . str_pad((substr($last_inv_no->maintenance_bill_master_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        // } else {
        //     $maintenance_bill_master_no = "SOVMB" . date("my") . "00001";
        // }

        $maintenance_bill_master_no = str_replace("Q", "B", $m_quotation_master->quotation_master_id);

        $data = array();
        $data['maintenance_bill_master_no'] = $maintenance_bill_master_no;
        $data['quotation_master_id'] = $m_quotation_master->quotation_master_id;
        $data['quotation_date'] = $m_quotation_master->quotation_date;
        $data['complain_id'] = $m_quotation_master->complain_id;
        $data['customer_id'] = $m_quotation_master->customer_id;
        $data['subject'] = $request->txt_subject;
        $data['discount'] = $m_quotation_master->approved_discount;
        $data['vat'] = $m_quotation_master->approved_vat;
        $data['ait'] = $m_quotation_master->approved_ait;
        $data['other'] = $m_quotation_master->approved_other;
        $data['grand_total'] = $m_quotation_master->approved_quotation_total;
        $data['status'] = 1;
        $data['entry_date'] = date('Y-m-d');
        $data['entry_time'] = date("h:i:s");
        $data['valid'] = 1;
        $data['user_id'] = Auth::user()->emp_id;

        $bill_master_id = DB::table('pro_maintenance_bill_master')->insertGetId($data);

        $m_quotation_details = DB::table('pro_maintenance_quotation_details')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->get();


        foreach ($m_quotation_details as $row) {
            $data2 = array();
            $data2['maintenance_bill_master_id'] = $bill_master_id;
            $data2['maintenance_bill_master_no'] = $maintenance_bill_master_no;
            $data2['quotation_master_id'] = $m_quotation_master->quotation_master_id;
            $data2['quotation_date'] = $m_quotation_master->quotation_date;
            $data2['customer_id'] = $m_quotation_master->customer_id;
            $data2['pg_id'] = $row->pg_id;
            $data2['pg_sub_id'] = $row->pg_sub_id;
            $data2['product_id'] = $row->product_id;
            $data2['qty'] = $row->approved_qty;
            $data2['rate'] = $row->approved_rate;
            $data2['sub_total'] = $row->approved_total;
            $data2['status'] = 1;
            $data2['user_id'] = Auth::user()->emp_id;
            $data2['entry_date'] = date('Y-m-d');
            $data2['entry_time'] = date("h:i:s");
            $data2['valid'] = 1;
            DB::table('pro_maintenance_bill_details')->insert($data2);
        }

        DB::table('pro_maintenance_quotation_master')
            ->where('quotation_id', $request->cbo_quotation_id)
            ->update(['bill_status' => 1]);

        return redirect()->route('rpt_mt_bill_view', $bill_master_id);
    }

    public function rpt_mt_bill_list()
    {

        $m_bill_master = DB::table('pro_maintenance_bill_master')
            ->leftJoin('pro_customers', 'pro_maintenance_bill_master.customer_id', 'pro_customers.customer_id')
            ->leftJoin('pro_employee_info', 'pro_maintenance_bill_master.user_id', 'pro_employee_info.employee_id')
            ->select(
                'pro_maintenance_bill_master.*',
                'pro_customers.customer_name',
                'pro_customers.customer_add',
                'pro_customers.customer_phone',
                'pro_employee_info.employee_name as prefer_by',
            )
            ->where('pro_maintenance_bill_master.status', 1)
            ->get();

        return view('maintenance.rpt_mt_bill_list', compact('m_bill_master'));
    }

    public function rpt_mt_bill_view($id)
    {

        $m_bill_master = DB::table('pro_maintenance_bill_master')
            ->leftJoin('pro_customers', 'pro_maintenance_bill_master.customer_id', 'pro_customers.customer_id')
            ->leftJoin('pro_employee_info', 'pro_maintenance_bill_master.user_id', 'pro_employee_info.employee_id')
            ->select(
                'pro_maintenance_bill_master.*',
                'pro_customers.customer_name',
                'pro_customers.customer_add',
                'pro_customers.customer_phone',
                'pro_employee_info.employee_name as prefer_by',
            )
            ->where('pro_maintenance_bill_master.maintenance_bill_master_id', $id)
            ->first();

        $m_bill_details = DB::table('pro_maintenance_bill_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_bill_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_bill_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_bill_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_bill_details.*',
                'pro_product.product_name',
                'pro_product_group.pg_id',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_id',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_bill_details.maintenance_bill_master_id', $id)
            ->get();

        return view('maintenance.rpt_mt_bill_view', compact('m_bill_master', 'm_bill_details'));
    }

    public function rpt_mt_bill_print($id)
    {

        $m_bill_master = DB::table('pro_maintenance_bill_master')
            ->leftJoin('pro_customers', 'pro_maintenance_bill_master.customer_id', 'pro_customers.customer_id')
            ->leftJoin('pro_employee_info', 'pro_maintenance_bill_master.user_id', 'pro_employee_info.employee_id')
            ->select(
                'pro_maintenance_bill_master.*',
                'pro_customers.customer_name',
                'pro_customers.customer_add',
                'pro_customers.customer_phone',
                'pro_employee_info.employee_name as prefer_by',
            )
            ->where('pro_maintenance_bill_master.maintenance_bill_master_id', $id)
            ->first();

        $m_bill_details = DB::table('pro_maintenance_bill_details')
            ->leftJoin('pro_product_group', 'pro_maintenance_bill_details.pg_id', 'pro_product_group.pg_id')
            ->leftJoin('pro_product_sub_group', 'pro_maintenance_bill_details.pg_sub_id', 'pro_product_sub_group.pg_sub_id')
            ->join('pro_product', 'pro_maintenance_bill_details.product_id', 'pro_product.product_id')
            ->select(
                'pro_maintenance_bill_details.*',
                'pro_product.product_name',
                'pro_product_group.pg_id',
                'pro_product_group.pg_name',
                'pro_product_sub_group.pg_sub_id',
                'pro_product_sub_group.pg_sub_name',
            )
            ->where('pro_maintenance_bill_details.maintenance_bill_master_id', $id)
            ->get();

        return view('maintenance.rpt_mt_bill_print', compact('m_bill_master', 'm_bill_details'));
    }


    //Ajx BILL
    public function GetBillCustomerQuotation($id)
    {
        $m_quotation_master = DB::table('pro_maintenance_quotation_master')
            ->leftJoin('pro_employee_info', 'pro_maintenance_quotation_master.mgm_confirm_approved_id', 'pro_employee_info.employee_id')
            ->leftJoin('pro_employee_info as prefer', 'pro_maintenance_quotation_master.confirm_approved_id', 'prefer.employee_id')
            ->leftJoin('pro_customers', 'pro_maintenance_quotation_master.customer_id', 'pro_customers.customer_id')
            ->select(
                'pro_maintenance_quotation_master.quotation_date',
                'pro_customers.customer_name',
                'pro_customers.customer_add',
                'pro_customers.customer_phone',
                'pro_employee_info.employee_name as approved_by',
                'prefer.employee_name as prefer_by'
            )
            ->where('pro_maintenance_quotation_master.quotation_id', $id)
            ->first();
        return response()->json($m_quotation_master);
    }

    //End Bill


    //Report 


    //Task complain
    public function RPTTaskComplain()
    {
        $form = date('Y-m-d');
        $to = date('Y-m-d');

        $m_task_register = DB::table('pro_complaint_register')
            ->leftJoin("pro_customers", "pro_customers.customer_id", "pro_complaint_register.customer_id")
            ->leftJoin("pro_projects", "pro_projects.project_id", "pro_complaint_register.project_id")
            ->leftJoin("pro_lifts", "pro_lifts.lift_id", "pro_complaint_register.lift_id")
            ->select("pro_complaint_register.*", "pro_customers.*", "pro_projects.*", "pro_lifts.*")
            ->where('pro_complaint_register.department_id', 2)
            ->where('pro_complaint_register.valid', '1')
            ->where('pro_complaint_register.entry_date', date('Y-m-d'))
            ->get();

        return view('maintenance.rpt_mt_task_complain', compact('m_task_register', 'form', 'to'));
    }



    //
    public function rpt_search_task_complain(Request $request)
    {
        $rules = [
            'txt_from' => 'required',
            'txt_to' => 'required',
        ];

        $customMessages = [
            'txt_from.required' => 'Form is Required.',
            'txt_to.required' => 'To is Required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $search_task_register = DB::table('pro_complaint_register')
            ->leftJoin("pro_customers", "pro_customers.customer_id", "pro_complaint_register.customer_id")
            ->leftJoin("pro_projects", "pro_projects.project_id", "pro_complaint_register.project_id")
            ->leftJoin("pro_lifts", "pro_lifts.lift_id", "pro_complaint_register.lift_id")
            ->select("pro_complaint_register.*", "pro_customers.*", "pro_projects.*", "pro_lifts.*")
            ->where('pro_complaint_register.department_id', 2)
            ->where('pro_complaint_register.valid', '1')
            ->whereBetween('pro_complaint_register.entry_date', [$request->txt_from, $request->txt_to])
            ->get();

        $form = $request->txt_from;
        $to = $request->txt_to;

        return view('maintenance.rpt_mt_task_complain', compact('search_task_register', 'form', 'to'));
    }
    //end task complain


    //RPT Task All
    public function RPTTaskAll()
    {
        $form = date('Y-m-d');
        $to = date('Y-m-d');

        $mt_task_assigns = DB::table('pro_task_assign')
            ->where('entry_date', date('Y-m-d'))
            ->where('department_id', 2)
            ->where('valid', 1)
            ->get();

        return view('maintenance.rpt_mt_task_all', compact('mt_task_assigns', 'form', 'to'));
    }
    //RPT Task Search
    public function RPTTaskSearch(Request $request)
    {
        $rules = [
            'txt_from' => 'required',
            'txt_to' => 'required',
        ];

        $customMessages = [
            'txt_from.required' => 'Form is Required.',
            'txt_to.required' => 'To is Required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $search_task = DB::table('pro_task_assign')
            ->whereBetween('entry_date', [$request->txt_from, $request->txt_to])
            ->where('department_id', 2)
            ->where('valid', 1)
            ->get();

        $form = $request->txt_from;
        $to = $request->txt_to;


        return view('maintenance.rpt_mt_task_all', compact('search_task', 'form', 'to'));
    }


    //rpt task View
    public function RPTTaskView($task_id)
    {
        $mt_task_assign = DB::table('pro_task_assign')
            ->where('task_id', $task_id)
            ->where('valid', 1)
            ->first();
        return view('maintenance.rpt_task_view', compact('mt_task_assign'));
    }

    //RPT Requation
    public function RPTRequisitionAll()
    {

        $form = date('Y-m-d');
        $to = date('Y-m-d');

        $m_requisition_master = DB::table('pro_requisition_master')
            ->whereNotIn('status', [1, 2])
            ->where('entry_date', date("Y-m-d"))
            ->where('department_id', 2)
            ->where('valid', 1)
            ->get();

        return view('maintenance.rpt_mt_requisition_all', compact('m_requisition_master', 'form', 'to'));
    }

    public function RPTRequisitionSearch(Request $request)
    {

        $rules = [
            'txt_from' => 'required',
            'txt_to' => 'required',
        ];

        $customMessages = [
            'txt_from.required' => 'Form is Required.',
            'txt_to.required' => 'To is Required.',
        ];
        $this->validate($request, $rules, $customMessages);

        $search_requisition_master = DB::table('pro_requisition_master')
            ->whereNotIn('status', [1, 2])
            ->whereBetween('entry_date', [$request->txt_from, $request->txt_to])
            ->where('department_id', 2)
            ->where('valid', 1)
            ->get();

        $form = $request->txt_from;
        $to = $request->txt_to;

        return view('maintenance.rpt_mt_requisition_all', compact('search_requisition_master', 'form', 'to'));
    }

    public function RPTRequisitionDetails($id)
    {

        $m_requisition_master = DB::table('pro_requisition_master')
            ->where('requisition_master_id', $id)
            ->where('valid', 1)
            ->first();

        $m_requisition_details = DB::table('pro_requisition_details')
            ->where('requisition_master_id', $id)
            ->where('valid', 1)
            ->get();
        return view('maintenance.rpt_requisition_details', compact('m_requisition_details', 'm_requisition_master'));
    }

    public function rpt_summery()
    {
        $form = date('Y-m-d');
        $to = date('Y-m-d');

        $m_task_register = DB::table('pro_complaint_register')
            ->leftJoin("pro_customers", "pro_customers.customer_id", "pro_complaint_register.customer_id")
            ->leftJoin("pro_projects", "pro_projects.project_id", "pro_complaint_register.project_id")
            // ->leftJoin("pro_lifts", "pro_lifts.lift_id", "pro_complaint_register.lift_id")
            ->select("pro_complaint_register.*", "pro_customers.customer_name", "pro_projects.project_name")
            ->where('pro_complaint_register.department_id', 2)
            ->where('pro_complaint_register.valid', '1')
            // ->where('pro_complaint_register.entry_date', date('Y-m-d'))
            ->get();

        return view('maintenance.rpt_summery', compact('m_task_register', 'form', 'to'));
    }
}
