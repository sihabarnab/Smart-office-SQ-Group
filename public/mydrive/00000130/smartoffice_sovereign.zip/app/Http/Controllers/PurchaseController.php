<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{


    public function indent_info()
    {
        $product_group = DB::table('pro_product_group')->where('valid', 1)->get();
        $m_master = DB::table('pro_indent_master')->where('status', 1)->get();
        return view('purchase.indent_info', compact('product_group', 'm_master'));
    }

    public function indent_store(Request $request)
    {

        $rules = [
            'txt_indent_date' => 'required',
            'txt_req_date' => 'required',
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_product_qty' => 'required',
        ];
        $customMessages = [
            'txt_indent_date.required' => 'Indent date is required.',
            'txt_req_date.required' => 'Product require date is required.',
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_product_qty.required' => 'QTY is required!',
            'txt_product_rate.required' => 'Rate is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $unit = DB::table('pro_product')->where('product_id', $request->cbo_product)->first();

        $last_inv_no = DB::table('pro_indent_master')->orderByDesc("indent_no")->first();
        if (isset($last_inv_no->indent_no)) {
            $indent_no = "SOVSN" . date("my") . str_pad((substr($last_inv_no->indent_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $indent_no = "SOVSN" . date("my") . "00001";
        }

        $data = array();
        $data['indent_no'] = $indent_no;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['unit_id'] = $unit->unit_id;
        $data['qty'] = $request->txt_product_qty;
        $data['remark'] = $request->txt_remark;
        $data['user_id'] = Auth::user()->emp_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");

        $master_id = DB::table('pro_indent_master')->insertGetId([
            'indent_no' => $indent_no,
            'indent_date' => $request->txt_indent_date,
            'require_date' => $request->txt_req_date,
            'user_id' => Auth::user()->emp_id,
            'status' => 1,
            'valid' => 1,
            'entry_date' => date("Y-m-d"),
            'entry_time' => date("h:i:sa"),
        ]);

        $data['indent_master_id'] = $master_id;
        DB::table('pro_indent_details')->insert($data);
        return redirect()->route('indent_details', $indent_no);
    }

    public function indent_details($id)
    {
        $m_master = DB::table('pro_indent_master')->where('indent_no', $id)->first();
        $m_details = DB::table('pro_indent_details')->where('indent_no', $id)->get();
        $product_group = DB::table('pro_product_group')->where('valid', 1)->get();
        return view('purchase.indent_details', compact('m_master', 'm_details', 'product_group'));
    }

    public function add_more_indent(Request $request, $id)
    {

        $rules = [
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_product_qty' => 'required',
        ];
        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_product_qty.required' => 'QTY is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $unit = DB::table('pro_product')->where('product_id', $request->cbo_product)->first();
        $m_master = DB::table('pro_indent_master')->where('indent_no', $id)->first();

        $data = array();
        $data['indent_no'] = $id;
        $data['indent_master_id'] = $m_master->indent_master_id;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['unit_id'] = $unit->unit_id;
        $data['qty'] = $request->txt_product_qty;
        $data['remark'] = $request->txt_remark;
        $data['user_id'] = Auth::user()->emp_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");

        DB::table('pro_indent_details')->insert($data);
        return back()->with('success', "Add Successfully!");
    }

    public function indent_final($id)
    {
        DB::table('pro_indent_master')->where('indent_no', $id)->update(['status' => 2]);
        DB::table('pro_indent_details')->where('indent_no', $id)->update(['status' => 2]);
        return redirect()->route('indent_info')->with('success', "Add Successfully!");
    }

    public function indent_approved()
    {
        $m_master =  DB::table('pro_indent_master')->where('status', 2)->get();
        return view('purchase.indent_approved_list', compact('m_master'));
    }

    public function indent_approved_details($id)
    {
        $m_master = DB::table('pro_indent_master')->where('indent_no', $id)->first();
        $m_details = DB::table('pro_indent_details')->where('indent_no', $id)->where('status', 2)->get();
        return view('purchase.indent_approved_final', compact('m_master', 'm_details'));
    }

    public function indent_approved_final(Request $request, $id)
    {
        $rules = [
            'txt_qty' => 'required',
        ];
        $customMessages = [
            'txt_qty.required' => 'QTY is required!',
        ];
        $this->validate($request, $rules, $customMessages);


        $m_details =  DB::table('pro_indent_details')->where('indent_details_id', $id)->first();

        DB::table('pro_indent_details')->where('indent_details_id', $id)->update([
            'status' => 3,
            'approved_qty' => $request->txt_qty,
            'approved_id' => Auth::user()->emp_id,
            'approved_entry_date' => date("Y-m-d"),
            'approved_entry_time' => date("h:i:sa"),
        ]);

        $data1 = DB::table('pro_indent_details')->where('indent_no', $m_details->indent_no)->count();
        $data2 = DB::table('pro_indent_details')->where('indent_no', $m_details->indent_no)->where('status', 3)->count();

        if ($data1 == $data2) {
            DB::table('pro_indent_master')->where('indent_no', $m_details->indent_no)->update([
                'status' => 3,
                'approved_id' => Auth::user()->emp_id,
                'approved_entry_date' => date("Y-m-d"),
                'approved_entry_time' => date("h:i:sa"),
            ]);

            return redirect()->route('indent_approved')->with('success', "Add Successfully!");
        } else {
            return back()->with('success', "Add Successfully!");
        }
    }

    public function rpt_indent_list()
    {
        $m_master = DB::table('pro_indent_master')->whereIn('status', [2, 3])->get();
        return view('purchase.rpt_indent_list', compact('m_master'));
    }

    public function rpt_indent_details($id)
    {
        $m_master = DB::table('pro_indent_master')->where('indent_no', $id)->first();
        $m_details = DB::table('pro_indent_details')->where('indent_no', $id)->get();
        return view('purchase.rpt_indent_details', compact('m_master', 'm_details'));
    }

    //End Indent 

    //quotation 

    public function quotation_info()
    {
        $m_master = DB::table('pro_indent_master')->where('status', 3)->where('quotation_status', null)->get();
        return view('purchase.quotation_info', compact('m_master'));
    }

    public function create_qutation($id)
    {
        $m_master = DB::table('pro_indent_master')->where('indent_no', $id)->first();
        $m_details = DB::table('pro_indent_details')->where('indent_no', $id)->get();
        $pg_id = DB::table('pro_indent_details')->where('indent_no', $id)->pluck('pg_id');
        $product_group = DB::table('pro_product_group')->whereIn('pg_id', $pg_id)->get();
        $m_supplyer = DB::table('pro_suppliers')->where('valid', 1)->get();
        $q_master = DB::table('pro_quotation_master')->where('status', 1)->get();
        return view('purchase.quotation_master', compact('m_master', 'm_details', 'product_group', 'm_supplyer', 'q_master'));
    }
    public function quotation_master_store(Request $request, $id)
    {
        $rules = [
            'cbo_supplier_id' => 'required|integer|between:1,10000',
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_product_qty' => 'required',
            'txt_product_rate' => 'required',
        ];
        $customMessages = [
            'cbo_supplier_id.required' => 'Select Supplyer.',
            'cbo_supplier_id.integer' => 'Select Supplyer.',
            'cbo_supplier_id.between' => 'Select Supplyer.',
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_product_qty.required' => 'QTY is required!',
            'txt_product_rate.required' => 'Rate is required!',

        ];
        $this->validate($request, $rules, $customMessages);

        $check = DB::table('pro_quotation_master')->where('indent_no', $id)->where('supplier_id', $request->cbo_supplier_id)->first();
        if (isset($check)) {
            return back()->with('warning', "This supplyer already selected.");
        } else {
            $m_master = DB::table('pro_indent_master')->where('indent_no', $id)->first();
            $unit = DB::table('pro_product')->where('product_id', $request->cbo_product)->first();
            $last_inv_no = DB::table('pro_quotation_master')->orderByDesc("quotation_invoice_no")->first();
            if (isset($last_inv_no->quotation_invoice_no)) {
                $Quotation_no = "SOVQU" . date("my") . str_pad((substr($last_inv_no->quotation_invoice_no, -5) + 1), 5, '0', STR_PAD_LEFT);
            } else {
                $Quotation_no = "SOVQU" . date("my") . "00001";
            }

            $data = array();
            $data['quotation_invoice_no'] = $Quotation_no;
            $data['indent_no'] = $m_master->indent_no;
            $data['indent_date'] = $m_master->indent_date;
            $data['pg_id'] = $request->cbo_product_group;
            $data['pg_sub_id'] = $request->cbo_product_sub_group;
            $data['product_id'] = $request->cbo_product;
            $data['unit_id'] = $unit->unit_id;
            $data['qty'] = $request->txt_product_qty;
            $data['rate'] = $request->txt_product_rate;
            $data['total'] = ($request->txt_product_qty * $request->txt_product_rate);
            $data['remark'] = $request->txt_remark;
            $data['user_id'] = Auth::user()->emp_id;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:sa");

            $master_id = DB::table('pro_quotation_master')->insertGetId([
                'quotation_invoice_no' => $Quotation_no,
                'indent_no' =>  $m_master->indent_no,
                'indent_date' =>  $m_master->indent_date,
                'reference' => $request->txt_ref,
                'supplier_id' => $request->cbo_supplier_id,
                'user_id' => Auth::user()->emp_id,
                'status' => 1,
                'valid' => 1,
                'entry_date' => date("Y-m-d"),
                'entry_time' => date("h:i:sa"),
            ]);

            $data['quotation_master_id'] = $master_id;
            DB::table('pro_quotation_details')->insert($data);
            return redirect()->route('quotation_details_info', $Quotation_no);
        }
    }

    public function  quotation_details_info($id)
    {
        $q_master = DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->first();
        $q_details = DB::table('pro_quotation_details')->where('quotation_invoice_no', $id)->get();
        // $m_master = DB::table('pro_indent_master')->where('indent_no', $q_master->indent_no)->first();

        $product_id = DB::table('pro_quotation_details')->where('quotation_invoice_no', $id)->pluck('product_id');
        $pg_id = DB::table('pro_indent_details')->where('indent_no', $q_master->indent_no)->whereNotIn('product_id', $product_id)->pluck('pg_id');
        $product_group = DB::table('pro_product_group')->whereIn('pg_id', $pg_id)->get();

        $m_supplyer = DB::table('pro_suppliers')->where('supplier_id', $q_master->supplier_id)->first();
        return view('purchase.quotation_details', compact('q_master', 'q_details', 'product_group', 'm_supplyer'));
    }

    public function quotation_details_info_store(Request $request, $id)
    {

        $rules = [
            'cbo_product_group' => 'required|integer|between:1,10000',
            'cbo_product_sub_group' => 'required|integer|between:1,10000',
            'cbo_product' => 'required|integer|between:1,10000',
            'txt_product_qty' => 'required',
            'txt_product_rate' => 'required',
        ];
        $customMessages = [
            'cbo_product_group.required' => 'Select Product Group.',
            'cbo_product_group.integer' => 'Select Product Group.',
            'cbo_product_group.between' => 'Select Product Group.',
            'cbo_product_sub_group.required' => 'Select Product Sub Group.',
            'cbo_product_sub_group.integer' => 'Select Product Sub Group.',
            'cbo_product_sub_group.between' => 'Select Product Sub Group.',
            'cbo_product.required' => 'Select Product',
            'cbo_product.integer' => 'Select Product',
            'cbo_product.between' => 'Select Product',
            'txt_product_qty.required' => 'QTY is required!',
            'txt_product_rate.required' => 'Rate is required!',

        ];
        $this->validate($request, $rules, $customMessages);
        $q_master = DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->first();
        $unit = DB::table('pro_product')->where('product_id', $request->cbo_product)->first();

        $data = array();
        $data['quotation_master_id'] = $q_master->quotation_master_id;
        $data['quotation_invoice_no'] = $q_master->quotation_invoice_no;
        $data['indent_no'] = $q_master->indent_no;
        $data['indent_date'] = $q_master->indent_date;
        $data['pg_id'] = $request->cbo_product_group;
        $data['pg_sub_id'] = $request->cbo_product_sub_group;
        $data['product_id'] = $request->cbo_product;
        $data['unit_id'] = $unit->unit_id;
        $data['qty'] = $request->txt_product_qty;
        $data['rate'] = $request->txt_product_rate;
        $data['total'] = ($request->txt_product_qty * $request->txt_product_rate);
        $data['remark'] = $request->txt_remark;
        $data['user_id'] = Auth::user()->emp_id;
        $data['status'] = 1;
        $data['valid'] = 1;
        $data['entry_date'] = date("Y-m-d");
        $data['entry_time'] = date("h:i:sa");
        DB::table('pro_quotation_details')->insert($data);
        return redirect()->route('quotation_details_info', $q_master->quotation_invoice_no);
    }

    public function quotation_final($id)
    {
        DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->update([
            'status' => '2'
        ]);
        DB::table('pro_quotation_details')->where('quotation_invoice_no', $id)->update([
            'status' => '2'
        ]);

        $q_master = DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->first();
        return view('purchase.quotation_file_upload', compact('q_master'));
    }

    public function quotation_file_upload(Request $request, $id)
    {
        $rules = [
            'txt_image' => 'required',
        ];
        $customMessages = [
            'txt_image.required' => 'Image is required!',

        ];
        $this->validate($request, $rules, $customMessages);

        $data = array();
        $image = $request->file('txt_image');
        if ($request->hasFile('txt_image')) {
            $filename = $id . '.' . $request->file('txt_image')->getClientOriginalExtension();
            $upload_path = "public/image/quotation/";
            $image_url = $upload_path . $filename;
            $image->move($upload_path, $filename);
            $data['image'] = $image_url;
        }

        $data['image_status'] = 1;
        DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->update($data);
        return redirect()->route('quotation_info');
    }

    public function quotation_approved_list()
    {
        $complite_indent = DB::table('pro_indent_master')->where('quotation_status', 1)->pluck('indent_no');
        $q_master = DB::table('pro_quotation_master')
            ->whereNotIn('indent_no', $complite_indent)
            // ->where('status', 2)
            ->where('image_status', 1)
            ->get();
        return view('purchase.quotation_approved_list', compact('q_master'));
    }

    public function quotation_approved_details($id)
    {
        $q_master = DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->first();
        $q_details = DB::table('pro_quotation_details')->where('quotation_invoice_no', $id)->where('status', 2)->get();
        return view('purchase.quotation_approved_details', compact('q_master', 'q_details'));
    }

    public function quotation_approved_final(Request $request, $id)
    {
        $rules = [
            'txt_qty' => 'required',
            'txt_rate' => 'required',
        ];
        $customMessages = [
            'txt_qty.required' => 'QTY is required!',
            'txt_rate.required' => 'Rate is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $q_details =  DB::table('pro_quotation_details')->where('quotation_details_id', $id)->first();

        // if ($request->txt_qty > $q_details->qty) {
        //     return back()->with('warning', "Approved Qty Gatter Then Qutation Qty ($request->txt_qty > $q_details->qty)!");
        // }

        DB::table('pro_quotation_details')->where('quotation_details_id', $id)->update([
            'status' => 3,
            'approved_qty' => $request->txt_qty,
            'approved_rate' => $request->txt_rate,
            'total' => ($request->txt_qty * $request->txt_rate),
            'approved_id' => Auth::user()->emp_id,
            'approved_entry_date' => date("Y-m-d"),
            'approved_entry_time' => date("h:i:sa"),
        ]);

        $data1 = DB::table('pro_quotation_details')->where('quotation_invoice_no', $q_details->quotation_invoice_no)->count();
        $data2 = DB::table('pro_quotation_details')->where('quotation_invoice_no', $q_details->quotation_invoice_no)->where('status', 3)->count();

        if ($data1 == $data2) {
            DB::table('pro_quotation_master')->where('quotation_invoice_no', $q_details->quotation_invoice_no)->update([
                'status' => 3,
                'approved_id' => Auth::user()->emp_id,
                'approved_entry_date' => date("Y-m-d"),
                'approved_entry_time' => date("h:i:sa"),
            ]);

            DB::table('pro_indent_master')->where('indent_no', $q_details->indent_no)->update([
                'quotation_status' => 1,
            ]);

            return redirect()->route('quotation_approved_list')->with('success', "Approved Successfully!");
        } else {
            return back()->with('success', "Add Successfully!");
        }
    }

    //RPT Quotation 
    public function rpt_quotation()
    {
        $q_master = DB::table('pro_quotation_master')
            ->where('image_status', 1)
            ->where('status', 3)
            ->get();
        return view('purchase.rpt_quotation', compact('q_master'));
    }
    public function rpt_quotation_details($id)
    {
        $q_master = DB::table('pro_quotation_master')
            ->where('quotation_invoice_no', $id)
            ->first();
        $q_details = DB::table('pro_quotation_details')
            ->where('quotation_invoice_no', $id)
            ->get();
        return view('purchase.rpt_quotation_details', compact('q_master', 'q_details'));
    }

    //Ajax Quotation
    public function GetQuotationIndentSub($id, $id2)
    {
        $pg_sub_id = DB::table('pro_indent_details')->where('indent_no', $id2)->pluck('pg_sub_id');
        $data = DB::table('pro_product_sub_group')
            ->where('pg_id', $id)
            ->whereIn('pg_sub_id', $pg_sub_id)
            ->get();

        return response()->json($data);
    }

    public function GetQuotationIndentProduct($id, $id2)
    {
        $product_id = DB::table('pro_indent_details')->where('indent_no', $id2)->pluck('product_id');
        $data = DB::table('pro_product')->where('pg_sub_id', $id)->whereIn('product_id', $product_id)->get();
        return response()->json($data);
    }

    public function GetQuotationIndentQty($id, $id2)
    {
        $data = DB::table('pro_indent_details')->where('indent_no', $id2)->where('product_id', $id)->first();
        return response()->json($data);
    }

    public function GetQuotationProduct($id, $id2, $id3)
    {
        $q_product_id = DB::table('pro_quotation_details')->where('quotation_invoice_no', $id3)->pluck('product_id');
        $product_id = DB::table('pro_indent_details')->where('indent_no', $id2)->whereNotIn('product_id', $q_product_id)->pluck('product_id');
        $data = DB::table('pro_product')
            ->whereIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->get();
        return response()->json($data);
    }

    //End quotation 

    //Work Order
    public function work_order_info()
    {
        $q_master =  DB::table('pro_quotation_master')->where('status', 3)->where('wo_status', null)->get();
        return view('purchase.work_order_info', compact('q_master'));
    }

    public function work_order_store($id)
    {
        $q_master =  DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->first();
        $q_details = DB::table('pro_quotation_details')->where('quotation_invoice_no', $id)->get();

        $last_inv_no = DB::table('pro_work_order_master')->orderByDesc("wo_invoice_no")->first();
        if (isset($last_inv_no->wo_invoice_no)) {
            $wo_invoice_no = "SOVWO" . date("my") . str_pad((substr($last_inv_no->wo_invoice_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $wo_invoice_no = "SOVWO" . date("my") . "00001";
        }

        $master_id = DB::table('pro_work_order_master')->insertGetId([
            'wo_invoice_no' => $wo_invoice_no,
            'quotation_invoice_no' => $q_master->quotation_invoice_no,
            'quotation_date' => $q_master->entry_date,
            'indent_no' =>  $q_master->indent_no,
            'indent_date' =>  $q_master->indent_date,
            'supplier_id' => $q_master->supplier_id,
            'reference' => $q_master->reference,
            'user_id' => Auth::user()->emp_id,
            'status' => 1,
            'valid' => 1,
            'entry_date' => date("Y-m-d"),
            'entry_time' => date("h:i:sa"),
        ]);

        foreach ($q_details as $value) {
            $data = array();
            $data['wo_master_id'] = $master_id;
            $data['wo_invoice_no'] = $wo_invoice_no;
            $data['quotation_invoice_no'] = $q_master->quotation_invoice_no;
            $data['quotation_date'] = $q_master->entry_date;
            $data['indent_no'] = $q_master->indent_no;
            $data['indent_date'] = $q_master->indent_date;
            $data['pg_id'] = $value->pg_id;
            $data['pg_sub_id'] = $value->pg_sub_id;
            $data['product_id'] = $value->product_id;
            $data['unit_id'] = $value->unit_id;
            $data['qty'] = $value->approved_qty;
            $data['rate'] = $value->approved_rate;
            $data['total'] = $value->total;
            $data['remark'] = $value->remark;
            $data['user_id'] = Auth::user()->emp_id;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:sa");
            DB::table('pro_work_order_details')->insert($data);
        }
        DB::table('pro_quotation_master')->where('quotation_invoice_no', $id)->update(['wo_status' => 1]);
        return back()->with('success', "Add Successfully!");
    }

    //Approved
    public function work_order_approved()
    {
        $wo_master =  DB::table('pro_work_order_master')->where('status', 1)->get();
        return view('purchase.work_order_approved', compact('wo_master'));
    }

    public function work_order_approved_details($id)
    {
        $wo_master =  DB::table('pro_work_order_master')->where('wo_invoice_no', $id)->first();
        $wo_details = DB::table('pro_work_order_details')->where('wo_invoice_no', $id)->where('status', 1)->get();
        return view('purchase.work_order_approved_details', compact('wo_master', 'wo_details'));
    }

    public function work_order_approved_final(Request $request, $id)
    {
        $rules = [
            'txt_qty' => 'required',
            'txt_rate' => 'required',
        ];
        $customMessages = [
            'txt_qty.required' => 'QTY is required!',
            'txt_rate.required' => 'Rate is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $q_details =  DB::table('pro_work_order_details')->where('wo_details_id', $id)->first();

        // if ($request->txt_qty > $q_details->qty) {
        //     return back()->with('warning', "Approved Qty Gatter Then Qutation Qty ($request->txt_qty > $q_details->qty)!");
        // }

        DB::table('pro_work_order_details')->where('wo_details_id', $id)->update([
            'status' => 2,
            'approved_qty' => $request->txt_qty,
            'approved_rate' => $request->txt_rate,
            'total' => ($request->txt_qty * $request->txt_rate),
            'approved_id' => Auth::user()->emp_id,
            'approved_entry_date' => date("Y-m-d"),
            'approved_entry_time' => date("h:i:sa"),
        ]);

        $data1 = DB::table('pro_work_order_details')->where('wo_invoice_no', $q_details->wo_invoice_no)->count();
        $data2 = DB::table('pro_work_order_details')->where('wo_invoice_no', $q_details->wo_invoice_no)->where('status', 2)->count();

        if ($data1 == $data2) {
            DB::table('pro_work_order_master')->where('wo_invoice_no', $q_details->wo_invoice_no)->update([
                'status' => 2,
                'approved_id' => Auth::user()->emp_id,
                'approved_entry_date' => date("Y-m-d"),
                'approved_entry_time' => date("h:i:sa"),
            ]);
            // DB::table('pro_quotation_master')->where('quotation_invoice_no', $q_details->quotation_invoice_no)->update(['wo_status',2]);
            return redirect()->route('work_order_approved')->with('success', "Approved Successfully!");
        } else {
            return back()->with('success', "Add Successfully!");
        }
    }

    //RPT Work Order 
    public function rpt_work_order_list()
    {
        $wo_master =  DB::table('pro_work_order_master')->where('status', 2)->get();
        return view('purchase.rpt_work_order_list', compact('wo_master'));
    }
    public function rpt_work_order_details($id)
    {
        $wo_master = DB::table('pro_work_order_master')
            ->where('wo_invoice_no', $id)
            ->first();
        $wo_details = DB::table('pro_work_order_details')
            ->where('wo_invoice_no', $id)
            ->get();
        return view('purchase.rpt_work_order_details', compact('wo_master', 'wo_details'));
    }


    // End Work Order

    //purchase
    public function purchase_info()
    {
        $wo_master = DB::table('pro_work_order_master')->where('purchase_status', null)->where('status', 2)->get();
        return view('purchase.purchase_info', compact('wo_master'));
    }

    public function purchase_information_store($id)
    {

        $wo_master =   DB::table('pro_work_order_master')->where('wo_invoice_no', $id)->first();
        $wo_details = DB::table('pro_work_order_details')->where('wo_invoice_no', $id)->get();

        $last_inv_no = DB::table('pro_purchase_master')->orderByDesc("purchase_no")->first();
        if (isset($last_inv_no->purchase_no)) {
            $purchase_no = "SOVPU" . date("my") . str_pad((substr($last_inv_no->purchase_no, -5) + 1), 5, '0', STR_PAD_LEFT);
        } else {
            $purchase_no = "SOVPU" . date("my") . "00001";
        }


        $master_id = DB::table('pro_purchase_master')->insertGetId([
            'purchase_no' => $purchase_no,
            'indent_no' => $wo_master->indent_no,
            'indent_date' => $wo_master->indent_date,
            'quotation_invoice_no' => $wo_master->quotation_invoice_no,
            'quotation_date' => $wo_master->quotation_date,
            'wo_invoice_no' => $wo_master->wo_invoice_no,
            'wo_invoice_date' => $wo_master->entry_date,
            'reference' => $wo_master->reference,
            'supplier_id' => $wo_master->supplier_id,
            'user_id' => Auth::user()->emp_id,
            'status' => 1,
            'valid' => 1,
            'entry_date' => date("Y-m-d"),
            'entry_time' => date("h:i:sa"),
        ]);

        foreach ($wo_details as $value) {
            $data = array();
            $data['purchase_master_id'] = $master_id;
            $data['purchase_no'] =  $purchase_no;
            $data['indent_no'] = $wo_master->indent_no;
            $data['indent_date'] = $wo_master->indent_date;
            $data['quotation_invoice_no'] = $wo_master->quotation_invoice_no;
            $data['quotation_date'] = $wo_master->quotation_date;
            $data['wo_invoice_no'] = $wo_master->wo_invoice_no;
            $data['wo_invoice_date'] = $wo_master->entry_date;

            $data['pg_id'] = $value->pg_id;
            $data['pg_sub_id'] = $value->pg_sub_id;
            $data['product_id'] = $value->product_id;
            $data['unit_id'] = $value->unit_id;
            $data['qty'] = $value->approved_qty;
            $data['rate'] = $value->approved_rate;
            $data['total'] = $value->total;
            $data['user_id'] = Auth::user()->emp_id;
            $data['remark'] = $value->remark;
            $data['status'] = 1;
            $data['valid'] = 1;
            $data['entry_date'] = date("Y-m-d");
            $data['entry_time'] = date("h:i:sa");
            DB::table('pro_purchase_details')->insert($data);
        }

        DB::table('pro_work_order_master')->where('wo_invoice_no', $id)->update([
            'purchase_status' => 1
        ]);

        return back()->with('success', "Add Successfully!");
    }

    public function purchase_approved()
    {
        $pu_master = DB::table('pro_purchase_master')->where('status', 1)->get();
        return view('purchase.purchase_approved', compact('pu_master'));
    }

    public function purchase_approved_details($id)
    {
        $pu_master = DB::table('pro_purchase_master')->where('purchase_no', $id)->first();
        $pu_details = DB::table('pro_purchase_details')->where('purchase_no', $id)->where('status', 1)->get();
        return view('purchase.purchase_approved_final', compact('pu_master', 'pu_details'));
    }

    public function purchase_approved_final(Request $request, $id)
    {
        $rules = [
            'txt_qty' => 'required',
            'txt_rate' => 'required',
        ];
        $customMessages = [
            'txt_qty.required' => 'QTY is required!',
            'txt_rate.required' => 'Rate is required!',
        ];
        $this->validate($request, $rules, $customMessages);

        $m_details =  DB::table('pro_purchase_details')->where('purchase_details_id', $id)->first();

        DB::table('pro_purchase_details')->where('purchase_details_id', $id)->update([
            'status' => 2,
            'approved_qty' => $request->txt_qty,
            'approved_rate' => $request->txt_rate,
            'total' => ($request->txt_qty * $request->txt_rate),
            'approved_id' => Auth::user()->emp_id,
            'approved_entry_date' => date("Y-m-d"),
            'approved_entry_time' => date("h:i:sa"),
        ]);

        $data1 = DB::table('pro_purchase_details')->where('purchase_no', $m_details->purchase_no)->count();
        $data2 = DB::table('pro_purchase_details')->where('purchase_no', $m_details->purchase_no)->where('status', 2)->count();

        if ($data1 == $data2) {

            DB::table('pro_purchase_master')->where('purchase_no', $m_details->purchase_no)->update([
                'status' => 2,
                'approved_id' => Auth::user()->emp_id,
                'approved_entry_date' => date("Y-m-d"),
                'approved_entry_time' => date("h:i:sa"),
            ]);
            return redirect()->route('purchase_approved')->with('success', "Add Successfully!");
        } else {
            return back()->with('success', "Add Successfully!");
        }
    }


    //rpt_purchase_list

    public function rpt_purchase_list()
    {
        $m_master = DB::table('pro_purchase_master')->where('status', 2)->get();
        return view('purchase.rpt_purchase_list', compact('m_master'));
    }

    public function rpt_purchase_details($id)
    {
        $pu_master = DB::table('pro_purchase_master')->where('purchase_no', $id)->first();
        $pu_details = DB::table('pro_purchase_details')->where('purchase_no', $id)->get();
        return view('purchase.rpt_purchase_details', compact('pu_master', 'pu_details'));
    }

    public function rpt_purchase_print($id)
    {
        $pu_master = DB::table('pro_purchase_master')->where('purchase_no', $id)->first();
        $pu_details = DB::table('pro_purchase_details')->where('purchase_no', $id)->get();
        return view('purchase.rpt_purchase_print', compact('pu_master', 'pu_details'));
    }



    //indent Ajax
    public function GetIndentGroup($id)
    {
        $data = DB::table('pro_product_sub_group')
            ->where('pg_id', $id)
            ->get();

        return response()->json($data);
    }


    public function GetIndentProduct($id)
    {
        $data = DB::table('pro_product')
            ->where('pg_sub_id', $id)
            ->get();

        return response()->json($data);
    }

    public function GetIndentProductDetails($id, $id2)
    {
        $product_id = DB::table('pro_indent_details')->where('indent_no', $id2)->pluck('product_id');

        $data = DB::table('pro_product')
            ->whereNotIn('product_id', $product_id)
            ->where('pg_sub_id', $id)
            ->get();

        return response()->json($data);
    }

    public function GetProductStoreUnit($id)
    {
        $product = DB::table('pro_product')
            ->where('product_id', $id)
            ->first();

        $data = DB::table('pro_units')->where('unit_id', $product->unit_id)->first();
        return response()->json($data);
    }

    public function GetSupplyAddress($id)
    {
        $data = DB::table('pro_suppliers')->where('supplier_id', $id)->where('valid', 1)->first();
        return response()->json($data);
    }
}
